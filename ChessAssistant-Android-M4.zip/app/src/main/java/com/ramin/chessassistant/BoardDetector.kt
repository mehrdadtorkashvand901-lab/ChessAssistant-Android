package com.ramin.chessassistant

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class BoardDetector {
    fun detect(bitmap: Bitmap): BoardGeometry? {
        val w = bitmap.width
        val h = bitmap.height
        val shortSide = min(w, h)

        // Fast path for the calibrated 691x1536 theme.
        if (w in 675..710 && h in 1500..1570) {
            val sx = w / 691f
            val sy = h / 1536f
            return BoardGeometry(
                Rect(
                    (20 * sx).toInt(),
                    (447 * sy).toInt(),
                    (670 * sx).toInt(),
                    (1097 * sy).toInt()
                ),
                0.98f
            )
        }

        var best: Rect? = null
        var bestScore = 0f
        var size = (shortSide * 0.96f).toInt()
        val minSize = (shortSide * 0.50f).toInt()
        val sizeStep = max(22, shortSide / 26)

        while (size >= minSize) {
            val cell = size / 8
            val centerLeft = (w / 2 - size / 2).coerceIn(0, max(0, w - size))
            val lefts = intArrayOf(
                centerLeft,
                (centerLeft - cell / 2).coerceAtLeast(0),
                (centerLeft + cell / 2).coerceAtMost(max(0, w - size))
            )
            var top = 0
            val topStep = max(18, cell / 2)

            while (top + size <= h) {
                for (left in lefts) {
                    val r = Rect(left, top, left + size, top + size)
                    val s = checkerScore(bitmap, r)
                    if (s > bestScore) { bestScore = s; best = Rect(r) }
                }
                top += topStep
            }
            size -= sizeStep
        }

        return if (best != null && bestScore >= 0.17f)
            BoardGeometry(best, bestScore.coerceIn(0f, 1f))
        else null
    }

    private fun checkerScore(bitmap: Bitmap, rect: Rect): Float {
        val cell = rect.width() / 8f
        val m = Array(8) { FloatArray(8) }
        for (r in 0..7) for (f in 0..7) m[r][f] = mean(bitmap, rect, f, r, cell)

        var diff = 0f
        var n = 0
        for (r in 0..7) for (f in 0..7) {
            if (f < 7) { diff += abs(m[r][f] - m[r][f+1]); n++ }
            if (r < 7) { diff += abs(m[r][f] - m[r+1][f]); n++ }
        }
        return (diff / max(1,n) / 255f).coerceIn(0f,1f)
    }

    private fun mean(bm: Bitmap, b: Rect, f: Int, r: Int, cell: Float): Float {
        val cx = (b.left + (f + .5f) * cell).toInt().coerceIn(0,bm.width-1)
        val cy = (b.top + (r + .5f) * cell).toInt().coerceIn(0,bm.height-1)
        val step = max(1,(cell*.18f).toInt())
        var s = 0f
        var n = 0
        for (dy in intArrayOf(-step,0,step)) for (dx in intArrayOf(-step,0,step)) {
            val c = bm.getPixel((cx+dx).coerceIn(0,bm.width-1),(cy+dy).coerceIn(0,bm.height-1))
            val rr=(c shr 16) and 255; val gg=(c shr 8) and 255; val bb=c and 255
            s += .2126f*rr + .7152f*gg + .0722f*bb
            n++
        }
        return s/max(1,n)
    }
}
