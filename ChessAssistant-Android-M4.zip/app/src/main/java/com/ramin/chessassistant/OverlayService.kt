package com.ramin.chessassistant

import android.app.Service
import android.content.*
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.view.WindowManager

class OverlayService : Service(), StockfishWebBridge.Listener {
    private lateinit var wm: WindowManager
    private var view: BoardOverlayView? = null
    private var engine: StockfishWebBridge? = null

    private var engineReady = false
    private var lastFen: String? = null
    private var lastSeq = -1L
    private var currentBoard: Rect? = null
    private var currentOrientation = Orientation.UNKNOWN

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action != CaptureService.ACTION_POSITION) return

            val found = i.getBooleanExtra(CaptureService.E_FOUND, false)
            val status = i.getStringExtra(CaptureService.E_STATUS) ?: ""

            if (!found) {
                currentBoard = null
                view?.updateBoard(null, status, Orientation.UNKNOWN)
                return
            }

            val r = Rect(
                i.getIntExtra(CaptureService.E_L, 0),
                i.getIntExtra(CaptureService.E_T, 0),
                i.getIntExtra(CaptureService.E_R, 0),
                i.getIntExtra(CaptureService.E_B, 0)
            )
            currentBoard = r

            currentOrientation =
                if (i.getStringExtra(CaptureService.E_ORIENTATION) == "B")
                    Orientation.BLACK_BOTTOM
                else if (i.getStringExtra(CaptureService.E_ORIENTATION) == "W")
                    Orientation.WHITE_BOTTOM
                else Orientation.UNKNOWN

            val fen = i.getStringExtra(CaptureService.E_FEN)
            val seq = i.getLongExtra(CaptureService.E_SEQ, -1L)

            val displayText = if (fen != null) {
                val side = if (fen.split(" ").getOrNull(1) == "b") "BLACK" else "WHITE"
                "$status • $side to move"
            } else status

            view?.updateBoard(r, displayText, currentOrientation)

            if (fen != null && seq >= 0 && seq != lastSeq) {
                lastSeq = seq
                lastFen = fen
                view?.updateMove(null)
                if (engineReady) {
                    engine?.analyze(seq.toString(), fen, 500)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = BoardOverlayView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        wm.addView(view, params)

        val f = IntentFilter(CaptureService.ACTION_POSITION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, f)
        }

        engine = StockfishWebBridge(this, this)
    }

    override fun onEngineReady() {
        engineReady = true
        val fen = lastFen
        if (fen != null && lastSeq >= 0) {
            engine?.analyze(lastSeq.toString(), fen, 500)
        }
    }

    override fun onBestMove(requestId: String, move: String) {
        if (requestId != lastSeq.toString()) return
        view?.updateMove(move)
    }

    override fun onEngineError(message: String) {
        view?.updateMove(null)
        currentBoard?.let {
            view?.updateBoard(it, "ENGINE ERROR", currentOrientation)
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        engine?.destroy()
        engine = null
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
