package com.ramin.chessassistant

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class BoardOverlayView(context: Context) : View(context) {
    private val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x7700FF00
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD54F.toInt()
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 13f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    private var board: Rect? = null
    private var status = ""
    private var move: String? = null
    private var orientation = Orientation.UNKNOWN

    fun updateBoard(rect: Rect?, text: String, orientation: Orientation) {
        board = rect?.let { Rect(it) }
        status = text
        this.orientation = orientation
        invalidate()
    }

    fun updateMove(uci: String?) {
        move = uci
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val r = board ?: return

        canvas.drawRect(r, boardPaint)
        val cell = r.width() / 8f
        for (i in 1 until 8) {
            val x = r.left + i * cell
            val y = r.top + i * cell
            canvas.drawLine(x, r.top.toFloat(), x, r.bottom.toFloat(), boardPaint)
            canvas.drawLine(r.left.toFloat(), y, r.right.toFloat(), y, boardPaint)
        }

        canvas.drawText(
            status,
            r.left.toFloat(),
            (r.top - 12).coerceAtLeast(35).toFloat(),
            textPaint
        )

        val uci = move ?: return
        val arrow = MoveMapper.map(uci, r, orientation) ?: return
        drawArrow(canvas, arrow.from, arrow.to)
    }

    private fun drawArrow(canvas: Canvas, from: PointF, to: PointF) {
        canvas.drawLine(from.x, from.y, to.x, to.y, arrowPaint)

        val angle = atan2(to.y - from.y, to.x - from.x)
        val head = 34f
        val spread = 0.55f

        val p1 = PointF(
            to.x - head * cos(angle - spread),
            to.y - head * sin(angle - spread)
        )
        val p2 = PointF(
            to.x - head * cos(angle + spread),
            to.y - head * sin(angle + spread)
        )

        canvas.drawLine(to.x, to.y, p1.x, p1.y, arrowPaint)
        canvas.drawLine(to.x, to.y, p2.x, p2.y, arrowPaint)
    }
}
