package com.ramin.chessassistant

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val detector = BoardDetector()
    private lateinit var recognizer: TemplatePieceRecognizer
    private val busy = AtomicBoolean(false)
    private var lastAnalyze = 0L

    private var candidateBoardFen: String? = null
    private var candidateCount = 0
    private var acceptedBoardFen: String? = null
    private var sideToMove = "w"
    private var sequence = 0L

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"

        const val ACTION_POSITION = "com.ramin.chessassistant.POSITION"
        const val E_FOUND = "found"
        const val E_L = "l"
        const val E_T = "t"
        const val E_R = "r"
        const val E_B = "b"
        const val E_ORIENTATION = "orientation"
        const val E_FEN = "fen"
        const val E_SEQ = "seq"
        const val E_STATUS = "status"

        private const val CH = "capture"
        private const val ID = 1001
        private const val ANALYZE_INTERVAL_MS = 500L
    }

    override fun onCreate() {
        super.onCreate()

        sideToMove = getSharedPreferences("assistant", MODE_PRIVATE)
            .getString("initial_side", "w") ?: "w"

        recognizer = TemplatePieceRecognizer(this)
        thread = HandlerThread("ChessVision").also { it.start() }
        handler = Handler(thread!!.looper)

        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CH, "Screen capture", NotificationManager.IMPORTANCE_LOW)
        )

        val n = Notification.Builder(this, CH)
            .setContentTitle("Chess Assistant")
            .setContentText("Vision + Stockfish pipeline active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(ID, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED

        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = pm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)

        reader = ImageReader.newInstance(
            m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2
        )

        reader?.setOnImageAvailableListener({ ir ->
            val now = System.currentTimeMillis()
            if (now - lastAnalyze < ANALYZE_INTERVAL_MS || busy.get()) {
                ir.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy.set(true)
            lastAnalyze = now

            try {
                val p = image.planes[0]
                val pad = p.rowStride - p.pixelStride * image.width
                val padded = Bitmap.createBitmap(
                    image.width + pad / p.pixelStride,
                    image.height,
                    Bitmap.Config.ARGB_8888
                )
                padded.copyPixelsFromBuffer(p.buffer)
                val bm = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                padded.recycle()

                val board = detector.detect(bm)
                if (board == null) {
                    broadcast(null, null, "NO BOARD")
                } else {
                    val rec = recognizer.recognize(bm, board.rect)

                    if (!rec.valid || rec.orientation == Orientation.UNKNOWN) {
                        broadcast(board, null, "VISION: ${rec.reason}")
                    } else {
                        stabilizeAndBroadcast(board, rec)
                    }
                }

                bm.recycle()
            } catch (_: Throwable) {
                broadcast(null, null, "VISION ERROR")
            } finally {
                image.close()
                busy.set(false)
            }
        }, handler)

        display = projection?.createVirtualDisplay(
            "ChessAssistant",
            m.widthPixels,
            m.heightPixels,
            m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface,
            null,
            handler
        )

        return START_NOT_STICKY
    }

    private fun stabilizeAndBroadcast(board: BoardGeometry, rec: Recognition) {
        if (candidateBoardFen == rec.fenBoard) {
            candidateCount++
        } else {
            candidateBoardFen = rec.fenBoard
            candidateCount = 1
        }

        // Require two consecutive frames before trusting a position.
        if (candidateCount < 2) {
            broadcast(board, null, "VERIFYING POSITION…")
            return
        }

        if (acceptedBoardFen != rec.fenBoard) {
            if (acceptedBoardFen != null) {
                sideToMove = if (sideToMove == "w") "b" else "w"
            }
            acceptedBoardFen = rec.fenBoard
            sequence++
        }

        val fullFen = "${rec.fenBoard} $sideToMove - - 0 1"
        val orient = if (rec.orientation == Orientation.WHITE_BOTTOM) "W" else "B"
        broadcast(board, Triple(fullFen, orient, sequence), "ENGINE READY")
    }

    private fun broadcast(
        board: BoardGeometry?,
        state: Triple<String, String, Long>?,
        status: String
    ) {
        val i = Intent(ACTION_POSITION).setPackage(packageName)
        i.putExtra(E_FOUND, board != null)
        i.putExtra(E_STATUS, status)

        board?.rect?.let {
            i.putExtra(E_L, it.left)
            i.putExtra(E_T, it.top)
            i.putExtra(E_R, it.right)
            i.putExtra(E_B, it.bottom)
        }

        state?.let {
            i.putExtra(E_FEN, it.first)
            i.putExtra(E_ORIENTATION, it.second)
            i.putExtra(E_SEQ, it.third)
        }

        sendBroadcast(i)
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
