package com.ramin.chessassistant

class PositionValidator {
    data class Result(val ok:Boolean,val reason:String)

    fun validate(grid:Array<Array<Piece?>>):Result {
        var wk=0; var bk=0; var wp=0; var bp=0
        for (row in grid) for (p in row) {
            if (p==null) continue
            if (p.color==PieceColor.WHITE) {
                wp++; if (p.type==PieceType.KING) wk++
            } else {
                bp++; if (p.type==PieceType.KING) bk++
            }
        }
        if (wk!=1) return Result(false,"white king count=$wk")
        if (bk!=1) return Result(false,"black king count=$bk")
        if (wp>16) return Result(false,"too many white pieces")
        if (bp>16) return Result(false,"too many black pieces")
        return Result(true,"ok")
    }
}
