# M4.1 Vision fix

Root cause found in the first live test:
the old recognizer re-classified all 32 3D pieces every frame and produced an impossible
"white king count=2".

M4.1 changes the strategy:
- "White / Black" now means MY COLOR.
- My color is assumed to be at the bottom, matching the target bot UI.
- Fresh games initialize from the exact standard chess starting position.
- After initialization, the app tracks changed squares instead of re-recognizing all piece types.
- Stockfish is only queried on the user's selected color turn.
- Ambiguous frame changes are rejected instead of corrupting the position.
- Basic castling tracking is included.

This should remove the specific double-king failure seen in the first live test.
