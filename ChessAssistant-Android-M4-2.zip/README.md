# ChessAssistant Android — M4

First end-to-end test milestone for bot/self-testing.

Pipeline:
1. MediaProjection captures the screen.
2. Calibrated vision detects the wood/3D board and pieces.
3. Two consecutive identical valid positions are required before acceptance.
4. Orientation is detected automatically.
5. The initial side to move is selected once before START.
6. After each accepted board change, side to move alternates automatically.
7. A FEN is generated.
8. Embedded Stockfish 18 Lite analyzes for 500 ms.
9. UCI bestmove is mapped back to board coordinates.
10. A yellow source→destination arrow is rendered on the overlay.

Engine assets come from the user's existing offline Stockfish HTML:
- Stockfish 18 Lite single-threaded loader
- embedded WASM + NNUE
- UCI bestmove format

Current first-test limitation:
- Castling rights and en-passant are emitted as "-" because full move-history reconstruction
  is not implemented yet. That can affect positions where castling/en-passant is relevant.
- The recognizer is calibrated specifically for the supplied wood/3D theme.
