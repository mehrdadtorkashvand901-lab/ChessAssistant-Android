package com.ramin.chessassistant

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class BoardDetector {

    /**
     * The supplied target screenshots use the same portrait board layout, but the
     * MediaProjection frame can be a different native resolution than the saved
     * screenshot (for example 720x1600 vs ~691x1536).
     *
     * M4.2 therefore uses NORMALIZED board coordinates instead of matching one
     * exact pixel resolution. This prevents the fallback detector from choosing
     * a slightly smaller board and makes the overlay grid line up with the real
     * 8x8 square boundaries.
     */
    fun detect(bitmap: Bitmap): BoardGeometry? {
        val w = bitmap.width
        val h = bitmap.height

        if (looksLikeTargetPortrait(w, h)) {
            val rect = calibratedTargetRect(w, h)
            return BoardGeometry(rect, 0.995f)
        }

        return fallbackDetect(bitmap)
    }

    private fun looksLikeTargetPortrait(w: Int, h: Int): Boolean {
        if (w <= 0 || h <= 0 || h <= w) return false
        val aspect = w.toFloat() / h.toFloat()
        // Target screenshots/native capture are around 0.45 aspect ratio.
        return aspect in 0.42f..0.48f
    }

    private fun calibratedTargetRect(w: Int, h: Int): Rect {
        // Calibrated from the actual playable 8x8 area in the user's screenshots:
        // source reference: 691 x 1536
        // playable board: x=20..670, y=447..1097
        //
        // Use normalized coordinates so this remains correct on native capture
        // resolutions such as 720x1600.
        val leftN   = 20f / 691f
        val topN    = 447f / 1536f
        val rightN  = 670f / 691f
        val bottomN = 1097f / 1536f

        var left   = (w * leftN).toInt()
        var top    = (h * topN).toInt()
        var right  = (w * rightN).toInt()
        var bottom = (h * bottomN).toInt()

        // Keep the board perfectly square. Use the smaller measured dimension and
        // preserve its center; this avoids subpixel/aspect drift between capture
        // and overlay coordinate spaces.
        val measuredW = right - left
        val measuredH = bottom - top
        val size = min(measuredW, measuredH)

        val cx = (left + right) / 2
        val cy = (top + bottom) / 2

        left = cx - size / 2
        right = left + size
        top = cy - size / 2
        bottom = top + size

        return Rect(
            left.coerceIn(0, w - 1),
            top.coerceIn(0, h - 1),
            right.coerceIn(1, w),
            bottom.coerceIn(1, h)
        )
    }

    private fun fallbackDetect(bitmap: Bitmap): BoardGeometry? {
        val w = bitmap.width
        val h = bitmap.height
        val shortSide = min(w, h)

        var best: Rect? = null
        var bestScore = 0f
        var size = (shortSide * 0.96f).toInt()
        val minSize = (shortSide * 0.50f).toInt()
        val sizeStep = max(22, shortSide / 26)

        while (size >= minSize) {
            val cell = size / 8
            val centerLeft = (w / 2 - size / 2).coerceIn(0, max(0, w - size))
            val lefts = intArrayOf(
                centerLeft,
                (centerLeft - cell / 2).coerceAtLeast(0),
                (centerLeft + cell / 2).coerceAtMost(max(0, w - size))
            )

            var top = 0
            val topStep = max(18, cell / 2)

            while (top + size <= h) {
                for (left in lefts) {
                    val r = Rect(left, top, left + size, top + size)
                    val s = checkerScore(bitmap, r)
                    if (s > bestScore) {
                        bestScore = s
                        best = Rect(r)
                    }
                }
                top += topStep
            }
            size -= sizeStep
        }

        return if (best != null && bestScore >= 0.17f) {
            BoardGeometry(best, bestScore.coerceIn(0f, 1f))
        } else null
    }

    private fun checkerScore(bitmap: Bitmap, rect: Rect): Float {
        val cell = rect.width() / 8f
        val m = Array(8) { FloatArray(8) }

        for (r in 0..7) for (f in 0..7) {
            m[r][f] = mean(bitmap, rect, f, r, cell)
        }

        var diff = 0f
        var n = 0
        for (r in 0..7) for (f in 0..7) {
            if (f < 7) {
                diff += abs(m[r][f] - m[r][f + 1])
                n++
            }
            if (r < 7) {
                diff += abs(m[r][f] - m[r + 1][f])
                n++
            }
        }

        return (diff / max(1, n) / 255f).coerceIn(0f, 1f)
    }

    private fun mean(
        bm: Bitmap,
        b: Rect,
        f: Int,
        r: Int,
        cell: Float
    ): Float {
        val cx = (b.left + (f + 0.5f) * cell).toInt().coerceIn(0, bm.width - 1)
        val cy = (b.top + (r + 0.5f) * cell).toInt().coerceIn(0, bm.height - 1)
        val step = max(1, (cell * 0.18f).toInt())

        var sum = 0f
        var n = 0

        for (dy in intArrayOf(-step, 0, step)) {
            for (dx in intArrayOf(-step, 0, step)) {
                val c = bm.getPixel(
                    (cx + dx).coerceIn(0, bm.width - 1),
                    (cy + dy).coerceIn(0, bm.height - 1)
                )
                val rr = (c shr 16) and 255
                val gg = (c shr 8) and 255
                val bb = c and 255
                sum += 0.2126f * rr + 0.7152f * gg + 0.0722f * bb
                n++
            }
        }
        return sum / max(1, n)
    }
}
