package com.ramin.chessassistant

import android.app.Service
import android.content.*
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager

class OverlayService : Service(), StockfishWebBridge.Listener {
    private lateinit var wm: WindowManager
    private var view: BoardOverlayView? = null
    private var engine: StockfishWebBridge? = null

    private var engineReady = false
    private var lastFen: String? = null
    private var lastSeq = -1L
    private var currentBoard: Rect? = null
    private var currentOrientation = Orientation.UNKNOWN
    private var myColor = "w"

    /** Tracker status (WHITE TO MOVE / BLACK TO MOVE / POSITION READY … / OUT OF SYNC …). */
    private var trackerStatus = ""
    /** Engine status for lastSeq: null, "ANALYZING", "BESTMOVE e2e4", "ENGINE LOADING…" */
    private var engineStatus: String? = null
    private var analyzeStartedAt = 0L
    private var lastPhase = ""

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action != CaptureService.ACTION_POSITION) return

            val found = i.getBooleanExtra(CaptureService.E_FOUND, false)
            val status = i.getStringExtra(CaptureService.E_STATUS) ?: ""
            view?.setFrameSize(
                i.getIntExtra(CaptureService.E_FW, 0),
                i.getIntExtra(CaptureService.E_FH, 0)
            )

            if (!found) {
                currentBoard = null
                view?.updateBoard(null, status, Orientation.UNKNOWN)
                return
            }

            val r = Rect(
                i.getIntExtra(CaptureService.E_L, 0),
                i.getIntExtra(CaptureService.E_T, 0),
                i.getIntExtra(CaptureService.E_R, 0),
                i.getIntExtra(CaptureService.E_B, 0)
            )
            currentBoard = r

            currentOrientation =
                if (i.getStringExtra(CaptureService.E_ORIENTATION) == "B")
                    Orientation.BLACK_BOTTOM
                else if (i.getStringExtra(CaptureService.E_ORIENTATION) == "W")
                    Orientation.WHITE_BOTTOM
                else Orientation.UNKNOWN

            val fen = i.getStringExtra(CaptureService.E_FEN)
            val seq = i.getLongExtra(CaptureService.E_SEQ, -1L)
            val phase = i.getStringExtra(CaptureService.E_PHASE) ?: ""
            trackerStatus = status
            lastPhase = phase

            when {
                phase == PositionTracker.Phase.OUT_OF_SYNC.name -> {
                    // Never analyse or show an arrow for a position we no longer trust.
                    // lastSeq is cleared so the same position is re-analysed once back in sync.
                    if (lastSeq >= 0) engine?.stop()
                    lastSeq = -1L
                    lastFen = null
                    engineStatus = null
                    view?.updateMove(null)
                }

                fen != null && seq >= 0 && seq != lastSeq -> {
                    lastSeq = seq
                    lastFen = fen
                    engineStatus = null
                    view?.updateMove(null)
                    requestAnalysisIfMyTurn(phase)
                }

                // Guard against a lost bestmove (e.g. WebView paused): re-issue after a timeout.
                engineStatus == "ANALYZING" &&
                    System.currentTimeMillis() - analyzeStartedAt > ANALYZE_TIMEOUT_MS -> {
                    requestAnalysisIfMyTurn(phase)
                }
            }

            refreshText()
        }
    }

    private fun requestAnalysisIfMyTurn(phase: String) {
        val fen = lastFen ?: return
        if (phase != PositionTracker.Phase.IN_SYNC.name) return          // game over / not ready
        val stm = fen.split(" ").getOrNull(1) ?: return
        if (stm != myColor) return                                         // opponent's turn
        if (!engineReady) { engineStatus = "ENGINE LOADING…"; return }
        engineStatus = "ANALYZING"
        analyzeStartedAt = System.currentTimeMillis()
        engine?.analyze(lastSeq.toString(), fen, 500)
    }

    private fun refreshText() {
        val text = engineStatus?.let { "$trackerStatus • $it" } ?: trackerStatus
        view?.updateBoard(currentBoard, text, currentOrientation)
    }

    override fun onCreate() {
        super.onCreate()

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = BoardOverlayView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            // Ask for a window that starts at display (0,0): do not get pushed below
            // the cutout / status bar or shrunk above the navigation bar.
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    if (Build.VERSION.SDK_INT >= 30)
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    else
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            if (Build.VERSION.SDK_INT >= 30) {
                fitInsetsTypes = 0
                isFitInsetsIgnoringVisibility = true
            }
        }
        // NOTE: the system/OEM may still place the window elsewhere. BoardOverlayView
        // therefore measures its real on-screen origin and compensates; these flags only
        // reduce how often compensation is needed.

        wm.addView(view, params)

        val f = IntentFilter(CaptureService.ACTION_POSITION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, f)
        }

        myColor = getSharedPreferences("assistant", MODE_PRIVATE)
            .getString("my_color", "w") ?: "w"
        engine = StockfishWebBridge(this, this)
    }

    override fun onEngineReady() {
        engineReady = true
        if (lastSeq >= 0 && engineStatus != "ANALYZING") {
            requestAnalysisIfMyTurn(lastPhase)
            refreshText()
        }
    }

    override fun onBestMove(requestId: String, move: String) {
        // Results for an older position (the board moved on) are dropped.
        if (requestId != lastSeq.toString()) return
        engineStatus = "BESTMOVE $move"
        view?.updateMove(move)
        refreshText()
    }

    override fun onEngineError(message: String) {
        engineStatus = "ENGINE ERROR"
        view?.updateMove(null)
        refreshText()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        engine?.destroy()
        engine = null
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null

    companion object {
        private const val ANALYZE_TIMEOUT_MS = 4000L
    }
}
