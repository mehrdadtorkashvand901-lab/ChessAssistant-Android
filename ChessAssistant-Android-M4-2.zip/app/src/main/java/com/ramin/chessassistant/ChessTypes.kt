package com.ramin.chessassistant

enum class PieceColor { WHITE, BLACK }
enum class PieceType(val fen: Char) {
    PAWN('p'), KNIGHT('n'), BISHOP('b'), ROOK('r'), QUEEN('q'), KING('k')
}
data class Piece(val color: PieceColor, val type: PieceType)
enum class Orientation { WHITE_BOTTOM, BLACK_BOTTOM, UNKNOWN }

data class Recognition(
    val grid: Array<Array<Piece?>>,
    val confidence: Array<FloatArray>,
    val orientation: Orientation,
    val fenBoard: String,
    val valid: Boolean,
    val reason: String
)
