package com.ramin.chessassistant

import android.graphics.Bitmap
import android.graphics.Rect

/**
 * How PositionTracker obtains its first position.
 *
 * All grids here are SCREEN grids (row 0 = top of the screen), the same convention
 * PositionTracker and FenBuilder use. Orientation is fixed by the caller.
 */
sealed class InitResult {
    data class Pending(val status: String) : InitResult()
    class Ready(
        val screenGrid: Array<Array<Piece?>>,
        /** "w" / "b", or null if unknown. */
        val sideToMove: String?,
        val status: String
    ) : InitResult()
}

interface PositionInitializer {
    /** Called once per analysed frame until it returns Ready. */
    fun offer(frame: Bitmap, board: Rect): InitResult
    fun reset()
}

/** M4.1 behaviour: assume the standard initial position (two stable frames). */
class StartPositionInitializer(private val orientation: Orientation) : PositionInitializer {
    private var frames = 0

    override fun offer(frame: Bitmap, board: Rect): InitResult {
        frames++
        if (frames < 2) return InitResult.Pending("VERIFYING START POSITION…")
        return InitResult.Ready(standardStartScreenGrid(orientation), "w", "START POSITION OK")
    }

    override fun reset() { frames = 0 }
}

/**
 * Arbitrary position from the current screenshot.
 *
 * Gates, in order — any failure returns Pending and the next frame is tried:
 *  1. temporal consensus: the last [framesNeeded] recognitions agree on all 64 squares
 *     (rejects piece animations, drag, highlight fade-in);
 *  2. per-square confidence: every square (empty or occupied) >= [minSquareConfidence]
 *     — a piece the templates can't match must NOT silently become an empty square;
 *  3. legality: PositionValidator + "side not to move is not in check".
 *
 * Side to move cannot be read reliably from a static board, so it is supplied.
 */
class RecognitionInitializer(
    private val recognizer: TemplatePieceRecognizer,
    private val orientation: Orientation,
    private val sideToMove: String,
    private val framesNeeded: Int = 3,
    private val minSquareConfidence: Float = 0.30f
) : PositionInitializer {

    private val window = ArrayDeque<Recognition>()

    override fun reset() = window.clear()

    override fun offer(frame: Bitmap, board: Rect): InitResult {
        window.addLast(recognizer.recognize(frame, board))
        while (window.size > framesNeeded) window.removeFirst()
        if (window.size < framesNeeded) {
            return InitResult.Pending("READING POSITION ${window.size}/$framesNeeded…")
        }

        val grid = Array(8) { arrayOfNulls<Piece>(8) }
        val unstable = mutableListOf<String>()
        val weak = mutableListOf<String>()

        for (r in 0..7) for (f in 0..7) {
            val labels = window.map { it.grid[r][f] }
            if (labels.distinct().size != 1) {
                unstable += squareName(r, f)
                continue
            }
            val meanConf = window.map { it.confidence[r][f] }.average().toFloat()
            if (meanConf < minSquareConfidence) weak += squareName(r, f)
            grid[r][f] = labels[0]
        }

        if (unstable.isNotEmpty()) {
            return InitResult.Pending("UNSTABLE: ${unstable.take(4).joinToString(",")}")
        }
        if (weak.isNotEmpty()) {
            return InitResult.Pending("LOW CONFIDENCE: ${weak.take(4).joinToString(",")}")
        }

        val v = PositionValidator().validate(grid)
        if (!v.ok) return InitResult.Pending("INVALID: ${v.reason}")

        if (sideNotToMoveInCheck(grid)) {
            return InitResult.Pending("INVALID: side not to move is in check (wrong side to move?)")
        }

        val hint = OrientationDetector().detect(grid)
        val note = if (hint != Orientation.UNKNOWN && hint != orientation) " (orientation hint disagrees)" else ""
        return InitResult.Ready(grid, sideToMove, "POSITION READ OK$note")
    }

    private fun squareName(screenRow: Int, screenFile: Int): String =
        if (orientation == Orientation.BLACK_BOTTOM) "${'h' - screenFile}${screenRow + 1}"
        else "${'a' + screenFile}${8 - screenRow}"

    /** Board grid: row 0 = rank 8, col 0 = file a. */
    private fun toBoard(screen: Array<Array<Piece?>>): Array<Array<Piece?>> {
        if (orientation != Orientation.BLACK_BOTTOM) return screen
        return Array(8) { r -> Array(8) { f -> screen[7 - r][7 - f] } }
    }

    private fun sideNotToMoveInCheck(screen: Array<Array<Piece?>>): Boolean {
        val b = toBoard(screen)
        val mover = if (sideToMove == "b") PieceColor.BLACK else PieceColor.WHITE
        val victim = if (mover == PieceColor.WHITE) PieceColor.BLACK else PieceColor.WHITE

        var kr = -1; var kf = -1
        for (r in 0..7) for (f in 0..7) {
            val p = b[r][f]
            if (p != null && p.color == victim && p.type == PieceType.KING) { kr = r; kf = f }
        }
        if (kr < 0) return false

        fun at(r: Int, f: Int) = if (r in 0..7 && f in 0..7) b[r][f] else null
        fun isMover(p: Piece?, vararg t: PieceType) = p != null && p.color == mover && p.type in t

        // Pawns (white moves toward row 0).
        val pr = if (mover == PieceColor.WHITE) kr + 1 else kr - 1
        if (isMover(at(pr, kf - 1), PieceType.PAWN) || isMover(at(pr, kf + 1), PieceType.PAWN)) return true

        // Knights and king.
        val knight = arrayOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1)
        if (knight.any { (dr, df) -> isMover(at(kr + dr, kf + df), PieceType.KNIGHT) }) return true
        for (dr in -1..1) for (df in -1..1) {
            if ((dr != 0 || df != 0) && isMover(at(kr + dr, kf + df), PieceType.KING)) return true
        }

        // Sliders.
        fun ray(dr: Int, df: Int, vararg t: PieceType): Boolean {
            var r = kr + dr; var f = kf + df
            while (r in 0..7 && f in 0..7) {
                val p = b[r][f]
                if (p != null) return isMover(p, *t)
                r += dr; f += df
            }
            return false
        }
        val straight = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
        val diag = arrayOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
        if (straight.any { (dr, df) -> ray(dr, df, PieceType.ROOK, PieceType.QUEEN) }) return true
        if (diag.any { (dr, df) -> ray(dr, df, PieceType.BISHOP, PieceType.QUEEN) }) return true
        return false
    }
}

internal fun standardStartScreenGrid(orientation: Orientation): Array<Array<Piece?>> {
    val canonical = Array(8) { arrayOfNulls<Piece>(8) }
    // canonical rows are rank 8 -> rank 1
    val back = arrayOf(
        PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
        PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
    )
    for (f in 0..7) {
        canonical[0][f] = Piece(PieceColor.BLACK, back[f])
        canonical[1][f] = Piece(PieceColor.BLACK, PieceType.PAWN)
        canonical[6][f] = Piece(PieceColor.WHITE, PieceType.PAWN)
        canonical[7][f] = Piece(PieceColor.WHITE, back[f])
    }
    if (orientation != Orientation.BLACK_BOTTOM) return canonical
    return Array(8) { r -> Array(8) { f -> canonical[7 - r][7 - f] } }
}
