package com.ramin.chessassistant
import android.graphics.Rect
data class BoardGeometry(val rect: Rect, val confidence: Float)
