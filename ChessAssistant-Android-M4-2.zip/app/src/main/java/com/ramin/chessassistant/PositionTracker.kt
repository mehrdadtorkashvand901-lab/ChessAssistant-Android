package com.ramin.chessassistant

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs

/**
 * M4.4 — the chess state is authoritative.
 *
 *  1. Initialise once through a PositionInitializer -> ChessState (board, side to move,
 *     castling, en passant).
 *  2. Keep a BASELINE of per-square signatures (3x3 sub-cells x RGB) taken from the last
 *     confirmed position.
 *  3. Only evaluate a frame when the board is visually SETTLED (no motion since the
 *     previous frame), so piece animations are never read half-way.
 *  4. Compare the settled frame against the baseline and accept a change ONLY if exactly
 *     one legal move sequence (1..MAX_PLIES plies, shortest first, for fast replies)
 *     explains it: its net board change matches the changed squares, every other changed
 *     square is a highlight square, and every changed square LOOKS like what the sequence
 *     puts there (self-calibrated empty / white / black appearance).
 *  5. Anything else — no fit, two fits, side-to-move parity unclear — leaves the state and
 *     baseline untouched. If it persists the tracker reports OUT OF SYNC; it recovers by
 *     itself when the board returns to the baseline or a legal explanation appears.
 *
 * Side to move is never toggled by hand: it is ChessState.sideToMove after apply().
 */
class PositionTracker(
    private val myColor: PieceColor,
    private val initializer: PositionInitializer =
        StartPositionInitializer(orientationFor(myColor))
) {

    enum class Phase { INITIALIZING, IN_SYNC, OUT_OF_SYNC, GAME_OVER }

    data class Update(
        /** Authoritative state; null until initialised. */
        val state: ChessState?,
        val orientation: Orientation,
        /** Increments on initialisation and on every applied move. */
        val version: Long,
        val phase: Phase,
        val status: String,
        /** UCI of the move(s) applied by THIS update, e.g. "e2e4" or "e2e4 e7e5". */
        val appliedMoves: String? = null
    ) {
        val fen: String? get() = state?.toFen()
    }

    val orientation: Orientation = orientationFor(myColor)

    private var state: ChessState? = null
    private var version = 0L
    private var baseline: FloatArray? = null
    private var lastFrame: FloatArray? = null
    private var lastMoveSquares: Set<Int> = emptySet()
    private var mismatchFrames = 0
    private var outOfSync = false
    private var lastProblem = ""
    /** Show "POSITION READY" until the first move has been tracked. */
    private var readyBanner = false

    /** Last evaluation detail (changed squares, rejection reason) — for logging/debugging. */
    var diagnostic: String = ""
        private set

    /** board square -> index in the screen-ordered hash array */
    private val hashIndexOf = IntArray(64).also { map ->
        for (sr in 0..7) for (sf in 0..7) map[ChessState.screenToSquare(sr, sf, orientation)] = sr * 8 + sf
    }

    /** Drop the tracked position; the next frames go through the initializer again. */
    fun reset() {
        state = null
        baseline = null
        lastFrame = null
        lastMoveSquares = emptySet()
        mismatchFrames = 0
        outOfSync = false
        initializer.reset()
    }

    fun update(bitmap: Bitmap, board: Rect): Update {
        val hashes = squareHashes(bitmap, board)
        val current = state

        // ---------------------------------------------------------------- initialise
        if (current == null) {
            return when (val r = initializer.offer(bitmap, board)) {
                is InitResult.Pending -> Update(null, orientation, version, Phase.INITIALIZING, r.status)
                is InitResult.Ready -> {
                    val stm = if (r.sideToMove == "b") PieceColor.BLACK else PieceColor.WHITE
                    val s = ChessState.fromScreenGrid(r.screenGrid, orientation, stm)
                    state = s
                    version++
                    baseline = hashes
                    lastFrame = hashes
                    lastMoveSquares = emptySet()
                    appearance.reset()
                    appearance.learn(s, hashes, emptySet())
                    readyBanner = true
                    Update(s, orientation, version, phaseOf(s), "POSITION READY • ${turnStatus(s)}")
                }
            }
        }

        // ---------------------------------------------------------------- settle
        val prevFrame = lastFrame ?: hashes
        lastFrame = hashes
        val motion = (0..63).maxOf { squareDiff(hashes, prevFrame, it) }
        if (motion > MOTION_THRESHOLD) {
            // Board is animating / being redrawn — never judge a half-drawn frame.
            return report(current)
        }

        // ---------------------------------------------------------------- compare to baseline
        val base = baseline ?: hashes
        val diff = FloatArray(64) { sq -> squareDiff(hashes, base, hashIndexOf[sq]) }
        val changed = (0..63).filter { diff[it] >= CHANGE_THRESHOLD }.toSet()

        if (changed.isEmpty()) {
            // Visual board == last confirmed position.
            mismatchFrames = 0
            outOfSync = false
            return report(current)
        }

        if (current.legalMoves().isEmpty()) {
            return report(current) // game over: nothing can legally change
        }

        val match = findExplanation(current, changed, diff, hashes)
        diagnostic = "changed=" + changed.sorted().joinToString(",") { ChessState.sqName(it) } +
            (if (match == null) " -> $lastProblem" + (if (lastDetail.isNotEmpty()) " ($lastDetail)" else "")
            else " -> " + match.joinToString(" ") { it.uci() })
        if (match == null) {
            mismatchFrames++
            if (mismatchFrames >= OUT_OF_SYNC_FRAMES) outOfSync = true
            return report(current)
        }

        // ---------------------------------------------------------------- advance
        var s: ChessState = current
        for (m in match) s = s.apply(m)
        state = s
        version++
        baseline = hashes
        // Order inside a multi-ply group is not observable, so any of its squares may carry
        // the UI's last-move highlight.
        lastMoveSquares = match.flatMap { it.touched() }.toSet()
        appearance.learn(s, hashes, lastMoveSquares + kingsOf(s))
        mismatchFrames = 0
        outOfSync = false
        readyBanner = false
        val ucis = match.joinToString(" ") { it.uci() }
        return Update(s, orientation, version, phaseOf(s), turnStatus(s), ucis)
    }

    // ------------------------------------------------------------------ matching

    private data class Cand(
        val moves: List<ChessState.Move>,
        val final: ChessState,
        /** changed squares explained only as highlight on/off (fewer is better) */
        val highlightOnly: Int,
        val score: Float
    )

    private var lastFailedKey: String? = null
    private var vetoes = 0
    private var lastVeto = ""
    private var lastDetail = ""

    /**
     * Finds the shortest legal move sequence (1..MAX_PLIES plies, iterative deepening) whose
     * NET board change explains the visual change:
     *
     *   - every square whose piece differs between the confirmed state and the candidate
     *     final state must be visually changed, and
     *   - every other visually changed square must be a highlight-only square: the previous
     *     move's from/to (last-move highlight removed), the final move's squares (new
     *     highlight) or a king square (check highlight on/off).
     *
     * Multi-ply sequences cover bots that reply faster than the board can be seen settled.
     * Returns null if nothing fits, or if two different final positions fit equally well.
     */
    private fun findExplanation(
        s: ChessState, changed: Set<Int>, diff: FloatArray, hashes: FloatArray
    ): List<ChessState.Move>? {
        lastDetail = ""
        if (changed.size > MAX_CHANGED_SQUARES) { lastProblem = "too many changed squares"; return null }

        // Same unexplained picture as last time: don't repeat an expensive failed search.
        val key = "$version:" + changed.sorted().joinToString(",")
        if (key == lastFailedKey) return null

        val baseTolerated = lastMoveSquares + kingsOf(s)
        var nodes = 0
        vetoes = 0

        fun search(plies: Int): List<Cand> {
            val found = ArrayList<Cand>()
            val path = ArrayList<ChessState.Move>()
            fun dfs(cur: ChessState) {
                if (nodes++ > NODE_LIMIT) return
                if (path.size == plies) {
                    evaluate(s, cur, path, changed, diff, baseTolerated, hashes)?.let { found += it }
                    return
                }
                for (m in cur.legalMoves()) {
                    // A static picture can't tell under-promotions apart; assume a queen.
                    if (m.promotion != null && m.promotion != PieceType.QUEEN) continue
                    // A move that touches no changed square would have to be undone later.
                    if (m.from !in changed && m.to !in changed) continue
                    path.add(m)
                    dfs(cur.apply(m))
                    path.removeAt(path.lastIndex)   // not removeLast(): JDK 21 API clash on Android
                }
            }
            dfs(s)
            return found
        }

        for (maxPlies in 1..MAX_PLIES) {
            val found = search(maxPlies)
            if (found.isNotEmpty()) {
                // Transpositions reach the same final position — that is not ambiguity.
                val distinct = found.groupBy { it.final.boardFen() + it.final.sideToMove }
                    .values.map { group -> group.first() }
                    .sortedWith(compareBy<Cand> { it.highlightOnly }.thenByDescending { it.score })
                val best = distinct[0]
                if (distinct.size > 1) {
                    val b = distinct[1]
                    if (best.highlightOnly == b.highlightOnly && best.score - b.score < AMBIGUITY_MARGIN) {
                        lastProblem = "ambiguous"
                        lastDetail = listOf(best, b).joinToString(" / ") { c -> c.moves.joinToString(" ") { it.uci() } }
                        lastFailedKey = key
                        return null
                    }
                }
                // Side-to-move parity: for multi-ply windows, a sequence one ply longer may reach
                // the SAME board with the OTHER side to move (one piece took a longer route).
                // The UI's last-move highlight separates most of these: the longer sequence only
                // counts if the picture also shows a change on its final move's squares. If it
                // still fits, refuse rather than guess.
                if (maxPlies >= 2) {
                    val board = best.final.boardFen()
                    val longer = search(maxPlies + 1)
                    if (longer.any {
                            it.final.boardFen() == board && it.final.sideToMove != best.final.sideToMove &&
                                it.moves.last().touched().all { sq -> sq in changed }
                        }) {
                        lastProblem = "side to move ambiguous"
                        lastDetail = "${best.moves.size} or ${maxPlies + 1} plies"
                        lastFailedKey = key
                        return null
                    }
                }
                return best.moves
            }
            if (nodes > NODE_LIMIT) break
        }
        lastProblem = if (nodes > NODE_LIMIT) "search limit" else "no legal move fits"
        if (vetoes > 0) lastDetail = "appearance vetoed $vetoes, e.g. $lastVeto"
        lastFailedKey = key
        return null
    }

    private fun evaluate(
        start: ChessState, final: ChessState, moves: List<ChessState.Move>,
        changed: Set<Int>, diff: FloatArray, baseTolerated: Set<Int>, hashes: FloatArray
    ): Cand? {
        var score = 0f
        val net = HashSet<Int>()
        for (sq in 0..63) {
            if (final[sq] != start[sq]) {
                if (sq !in changed) return null       // board changed here but the picture didn't
                net += sq
                score += diff[sq]
            }
        }
        // Piece-trail rule: no move may start or end on a square the sequence leaves net
        // unchanged unless the trail continues there (a piece arrived earlier / moves on or
        // is captured later). Rejects "out and back" shuffles, which fit any picture and flip
        // the side to move.
        for (i in moves.indices) {
            val m = moves[i]
            val fromOk = m.from in net || (0 until i).any { moves[it].to == m.from }
            val toOk = m.to in net || (i + 1 until moves.size).any { moves[it].from == m.to || moves[it].to == m.to }
            if (!fromOk || !toOk) return null
        }
        val tolerated = baseTolerated + kingsOf(final) + moves.last().touched()
        var highlightOnly = 0
        for (sq in changed) {
            if (final[sq] != start[sq]) continue
            if (sq !in tolerated) return null        // picture changed here but the board didn't
            highlightOnly++
        }
        // Every net-changed square must LOOK like what the candidate says is there (empty /
        // white piece / black piece). Rejects popups, glitches, piece-selection states
        // (selected piece still on its square) and wrong captures that happen to fit a legal
        // sequence. A highlight tints the square background, not the piece, so it neither
        // fakes nor hides a piece and leaves the piece colour (centre sub-cell) readable.
        // Highlight-only squares are checked too: a highlight may change a square's colour,
        // never whether a piece stands on it.
        for (sq in changed) {
            if (!appearance.agrees(sq, final[sq], hashes, checkColour = sq in net)) {
                vetoes++
                lastVeto = moves.joinToString(" ") { it.uci() } + "@" + ChessState.sqName(sq)
                return null
            }
        }
        return Cand(moves.toList(), final, highlightOnly, score)
    }

    private fun kingsOf(s: ChessState): Set<Int> =
        setOf(s.kingSquare(PieceColor.WHITE), s.kingSquare(PieceColor.BLACK))

    // ------------------------------------------------------------------ appearance

    private val appearance = AppearanceModel()

    /**
     * Self-calibrating appearance model. While in sync the tracker KNOWS what stands on every
     * square, so it learns — per square shade — a centroid for "empty", "white piece" and
     * "black piece" from two cheap features of the 3x3 signature:
     *   contrast = |centre - mean(corners)|   (a piece breaks the flat square colour)
     *   centre   = centre sub-cell value       (white vs black piece)
     * A candidate is vetoed if a changed square is clearly closer to another class than to
     * the one the candidate predicts. Until a class has been seen it never vetoes.
     */
    private inner class AppearanceModel {
        private inner class Centroid {
            var n = 0; var c = 0f; var l = 0f
            fun add(contrast: Float, centre: Float) {
                n++
                val k = minOf(n, 200)
                c += (contrast - c) / k
                l += (centre - l) / k
            }
            fun dist(contrast: Float, centre: Float) = abs(contrast - c) + abs(centre - l)
        }
        // [shade][class]: class 0 = empty, 1 = white piece, 2 = black piece
        private var model = Array(2) { Array(3) { Centroid() } }

        fun reset() { model = Array(2) { Array(3) { Centroid() } } }

        private fun shade(sq: Int) = ((sq / 8) + (sq % 8)) % 2
        private fun cls(p: Piece?) = when { p == null -> 0; p.color == PieceColor.WHITE -> 1; else -> 2 }
        private fun cellLuma(h: FloatArray, sq: Int, cell: Int): Float {
            val b = hashIndexOf[sq] * F + cell * 3
            return 0.50f * h[b] + 0.30f * h[b + 1] + 0.20f * h[b + 2]
        }
        /** Brightness spread of the 9 sub-cells: flat for empty / tinted / popup, high for a piece. */
        private fun contrast(h: FloatArray, sq: Int): Float {
            var lo = cellLuma(h, sq, 0); var hi = lo
            for (k in 1 until CELLS) { val v = cellLuma(h, sq, k); lo = minOf(lo, v); hi = maxOf(hi, v) }
            return hi - lo
        }
        private fun centre(h: FloatArray, sq: Int) = cellLuma(h, sq, 4)

        fun learn(s: ChessState, h: FloatArray, exclude: Set<Int>) {
            for (sq in 0..63) {
                if (sq in exclude) continue
                model[shade(sq)][cls(s[sq])].add(contrast(h, sq), centre(h, sq))
            }
        }

        fun agrees(sq: Int, expected: Piece?, h: FloatArray, checkColour: Boolean = true): Boolean {
            val m = model[shade(sq)]
            if (m.any { it.n == 0 }) return true
            val c = contrast(h, sq); val l = centre(h, sq)

            // Stage 1 — occupancy from contrast only. A piece breaks the flat square colour;
            // empty squares, highlight tints and popups/glitches are flat.
            val emptyC = m[0].c
            val occC = minOf(m[1].c, m[2].c)
            if (occC - emptyC < MIN_SEPARATION) return true      // not separable yet
            val threshold = (emptyC + occC) / 2f
            val looksOccupied = c > threshold
            if (looksOccupied != (expected != null)) {
                // Allow a margin around the threshold before vetoing.
                if (abs(c - threshold) > MIN_SEPARATION / 2f) return false
            }
            if (expected == null || !looksOccupied || !checkColour) return true

            // Stage 2 — colour from the centre value, only when the square looks occupied.
            if (abs(m[1].l - m[2].l) < MIN_SEPARATION) return true
            val looksWhite = abs(l - m[1].l) < abs(l - m[2].l)
            return looksWhite == (expected.color == PieceColor.WHITE)
        }
    }

    // ------------------------------------------------------------------ status

    private fun report(s: ChessState): Update {
        val status = when {
            outOfSync -> "OUT OF SYNC • $lastProblem"
            readyBanner -> "POSITION READY • ${turnStatus(s)}"
            else -> turnStatus(s)
        }
        val phase = if (outOfSync) Phase.OUT_OF_SYNC else phaseOf(s)
        return Update(s, orientation, version, phase, status)
    }

    private fun phaseOf(s: ChessState): Phase =
        if (s.legalMoves().isEmpty()) Phase.GAME_OVER else Phase.IN_SYNC

    private fun turnStatus(s: ChessState): String {
        if (s.legalMoves().isEmpty()) return if (s.inCheck()) "CHECKMATE" else "STALEMATE"
        val side = if (s.sideToMove == PieceColor.WHITE) "WHITE TO MOVE" else "BLACK TO MOVE"
        return if (s.inCheck()) "$side (CHECK)" else side
    }

    // ------------------------------------------------------------------ hashing

    /**
     * Per-square signature: mean R, G, B of 3x3 sub-cells (27 values per square, screen order).
     * A single brightness mean per square (M4.1–M4.3) cannot tell "piece on square" from
     * "empty square with a highlight" when the averages happen to match, and it barely sees
     * a coloured highlight on a dark square. Spatial layout + colour channels see both.
     */
    private fun squareHashes(bitmap: Bitmap, board: Rect): FloatArray {
        val out = FloatArray(64 * F)
        val sums = FloatArray(F)
        val counts = IntArray(CELLS)
        val cell = board.width() / 8f

        for (r in 0..7) for (f in 0..7) {
            val x0 = board.left + f * cell
            val y0 = board.top + r * cell
            val margin = cell / 12f            // ignore grid lines / board borders
            val inner = cell - 2 * margin
            val step = maxOf(1f, inner / 12f)  // ~12x12 samples per square
            sums.fill(0f); counts.fill(0)

            var y = margin + step / 2
            while (y < cell - margin) {
                var x = margin + step / 2
                val by = (((y - margin) / inner) * 3).toInt().coerceIn(0, 2)
                while (x < cell - margin) {
                    val bx = (((x - margin) / inner) * 3).toInt().coerceIn(0, 2)
                    val c = bitmap.getPixel(
                        (x0 + x).toInt().coerceIn(0, bitmap.width - 1),
                        (y0 + y).toInt().coerceIn(0, bitmap.height - 1)
                    )
                    val k = by * 3 + bx
                    sums[k * 3] += ((c shr 16) and 255) / 255f
                    sums[k * 3 + 1] += ((c shr 8) and 255) / 255f
                    sums[k * 3 + 2] += (c and 255) / 255f
                    counts[k]++
                    x += step
                }
                y += step
            }
            val base = (r * 8 + f) * F
            for (k in 0 until F) out[base + k] = if (counts[k / 3] > 0) sums[k] / counts[k / 3] else 0f
        }
        return out
    }

    /** Largest sub-cell difference of one screen square between two signatures. */
    private fun squareDiff(a: FloatArray, b: FloatArray, screenIdx: Int): Float {
        var m = 0f
        val base = screenIdx * F
        for (k in 0 until F) m = maxOf(m, abs(a[base + k] - b[base + k]))
        return m
    }

    companion object {
        /** 3x3 sub-cells per square, 3 colour channels each. */
        private const val CELLS = 9
        private const val F = CELLS * 3
        /** Per-square change vs baseline that counts as "changed" (same as M4.1–M4.3). */
        const val CHANGE_THRESHOLD = 0.050f
        /** Max per-square change between consecutive frames for the board to count as settled. */
        const val MOTION_THRESHOLD = 0.020f
        /** Settled-but-unexplained frames before reporting OUT OF SYNC (~2 s at 200 ms). */
        const val OUT_OF_SYNC_FRAMES = 10
        /** Longest move sequence searched between two settled frames (fast bot replies). */
        const val MAX_PLIES = 3
        /** Search budget per evaluation (each node = one legal-move generation). */
        const val NODE_LIMIT = 6000
        /** MAX_PLIES moves plus highlight squares stay under this. MAX_PLIES = 3: in stress
         *  tests 4 plies mostly added wrong guesses in windows a static picture can't resolve. */
        const val MAX_CHANGED_SQUARES = 20
        /** Minimum learned feature gap before the appearance model may veto a candidate. */
        const val MIN_SEPARATION = 0.03f
        /** Required score gap between the best and second-best explanation. */
        const val AMBIGUITY_MARGIN = 0.04f
    }
}

internal fun orientationFor(myColor: PieceColor): Orientation =
    if (myColor == PieceColor.WHITE) Orientation.WHITE_BOTTOM else Orientation.BLACK_BOTTOM
