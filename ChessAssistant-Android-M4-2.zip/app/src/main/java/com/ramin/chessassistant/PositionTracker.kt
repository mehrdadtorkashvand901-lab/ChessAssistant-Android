package com.ramin.chessassistant

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs

/**
 * M4.1 strategy:
 * - At a fresh game, initialize from the known standard chess starting position.
 * - The user's selected color is assumed to be at the bottom of the screen.
 * - After that, track moves by detecting which board squares changed visually.
 *
 * This is substantially more robust than classifying all 32 pieces from scratch
 * on every frame, especially with 3D pieces and green last-move highlights.
 */
class PositionTracker(private val myColor: PieceColor) {

    data class Update(
        val grid: Array<Array<Piece?>>,
        val orientation: Orientation,
        val boardFen: String,
        val changedSquares: List<Pair<Int, Int>>,
        val accepted: Boolean,
        val status: String
    )

    private var grid: Array<Array<Piece?>>? = null
    private var previousHashes: FloatArray? = null
    private var stableFrames = 0

    val orientation: Orientation =
        if (myColor == PieceColor.WHITE) Orientation.WHITE_BOTTOM
        else Orientation.BLACK_BOTTOM

    fun update(bitmap: Bitmap, board: Rect): Update {
        val hashes = squareHashes(bitmap, board)

        if (grid == null) {
            stableFrames++
            if (stableFrames < 2) {
                return Update(
                    emptyGrid(), orientation, "", emptyList(), false,
                    "VERIFYING START POSITION…"
                )
            }

            grid = standardStartScreenGrid(orientation)
            previousHashes = hashes
            val fen = FenBuilder().build(grid!!, orientation)
            return Update(grid!!, orientation, fen, emptyList(), true, "START POSITION OK")
        }

        val prev = previousHashes ?: hashes
        val diffs = hashes.indices.map { i -> i to abs(hashes[i] - prev[i]) }
            .sortedByDescending { it.second }

        // Dynamic threshold: the 2 strongest changed squares must be clearly stronger
        // than the normal frame-to-frame noise.
        val strong = diffs.filter { it.second >= 0.050f }.take(6)
        val changed = strong.map { idx ->
            Pair(idx.first % 8, idx.first / 8)
        }

        if (changed.size < 2) {
            previousHashes = hashes
            return Update(
                grid!!, orientation, FenBuilder().build(grid!!, orientation),
                changed, false, "WAITING FOR MOVE"
            )
        }

        // For normal moves/captures, the two strongest squares are source+destination.
        val a = strong[0].first
        val b = strong[1].first
        val aFile = a % 8; val aRow = a / 8
        val bFile = b % 8; val bRow = b / 8

        val boardGrid = grid!!
        val pa = boardGrid[aRow][aFile]
        val pb = boardGrid[bRow][bFile]

        // Determine source by which changed square currently contains the side-to-move piece.
        // If ambiguous, reject rather than corrupting the position.
        val source: Pair<Int,Int>
        val dest: Pair<Int,Int>

        if (pa != null && pb == null) {
            source = aFile to aRow
            dest = bFile to bRow
        } else if (pb != null && pa == null) {
            source = bFile to bRow
            dest = aFile to aRow
        } else if (pa != null && pb != null && pa.color != pb.color) {
            // capture: choose the piece whose color is expected to move next
            // Caller toggles side after accepted board change, so either direction is possible;
            // prefer the square with the larger visual change as destination only if needed.
            source = aFile to aRow
            dest = bFile to bRow
        } else {
            previousHashes = hashes
            return Update(
                boardGrid, orientation, FenBuilder().build(boardGrid, orientation),
                changed, false, "MOVE CHANGE AMBIGUOUS"
            )
        }

        val moving = boardGrid[source.second][source.first]
        if (moving == null) {
            previousHashes = hashes
            return Update(
                boardGrid, orientation, FenBuilder().build(boardGrid, orientation),
                changed, false, "NO SOURCE PIECE"
            )
        }

        boardGrid[dest.second][dest.first] = moving
        boardGrid[source.second][source.first] = null

        // Basic castling support when four squares changed:
        if (strong.size >= 4 && moving.type == PieceType.KING) {
            tryApplyRookCastle(boardGrid, source, dest)
        }

        previousHashes = hashes
        val fen = FenBuilder().build(boardGrid, orientation)
        return Update(boardGrid, orientation, fen, changed, true, "MOVE TRACKED")
    }

    private fun tryApplyRookCastle(
        g: Array<Array<Piece?>>,
        source: Pair<Int,Int>,
        dest: Pair<Int,Int>
    ) {
        val dx = dest.first - source.first
        if (kotlin.math.abs(dx) != 2) return
        val row = source.second
        if (dx > 0) {
            val rook = g[row][7] ?: return
            if (rook.type == PieceType.ROOK) {
                g[row][5] = rook
                g[row][7] = null
            }
        } else {
            val rook = g[row][0] ?: return
            if (rook.type == PieceType.ROOK) {
                g[row][3] = rook
                g[row][0] = null
            }
        }
    }

    private fun squareHashes(bitmap: Bitmap, board: Rect): FloatArray {
        val out = FloatArray(64)
        val cell = board.width() / 8f
        var idx = 0

        for (r in 0..7) for (f in 0..7) {
            val x0 = (board.left + f * cell).toInt()
            val y0 = (board.top + r * cell).toInt()
            val x1 = (board.left + (f + 1) * cell).toInt()
            val y1 = (board.top + (r + 1) * cell).toInt()

            // Sample the inner square so grid/board borders have little influence.
            var sum = 0f
            var n = 0
            val sx = maxOf(2, (x1 - x0) / 6)
            val sy = maxOf(2, (y1 - y0) / 6)

            var y = y0 + sy
            while (y < y1 - sy) {
                var x = x0 + sx
                while (x < x1 - sx) {
                    val c = bitmap.getPixel(
                        x.coerceIn(0, bitmap.width - 1),
                        y.coerceIn(0, bitmap.height - 1)
                    )
                    val rr = (c shr 16) and 255
                    val gg = (c shr 8) and 255
                    val bb = c and 255
                    // Include chroma as well as brightness so green move highlight is captured.
                    sum += (0.50f * rr + 0.30f * gg + 0.20f * bb) / 255f
                    n++
                    x += sx
                }
                y += sy
            }
            out[idx++] = if (n > 0) sum / n else 0f
        }
        return out
    }

    private fun standardStartScreenGrid(orientation: Orientation): Array<Array<Piece?>> {
        val canonical = Array(8) { arrayOfNulls<Piece>(8) }

        // canonical rows are rank 8 -> rank 1
        val back = arrayOf(
            PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
            PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
        )

        for (f in 0..7) {
            canonical[0][f] = Piece(PieceColor.BLACK, back[f])
            canonical[1][f] = Piece(PieceColor.BLACK, PieceType.PAWN)
            canonical[6][f] = Piece(PieceColor.WHITE, PieceType.PAWN)
            canonical[7][f] = Piece(PieceColor.WHITE, back[f])
        }

        if (orientation == Orientation.WHITE_BOTTOM) return canonical

        val screen = Array(8) { arrayOfNulls<Piece>(8) }
        for (r in 0..7) for (f in 0..7) {
            screen[r][f] = canonical[7-r][7-f]
        }
        return screen
    }

    private fun emptyGrid() = Array(8) { arrayOfNulls<Piece>(8) }
}
