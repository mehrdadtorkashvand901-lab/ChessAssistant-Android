package com.ramin.chessassistant

class OrientationDetector {
    fun detect(grid: Array<Array<Piece?>>): Orientation {
        var whiteTop=0f; var whiteBottom=0f
        var blackTop=0f; var blackBottom=0f

        for (r in 0..7) for (f in 0..7) {
            val p=grid[r][f] ?: continue
            val topWeight=(7-r)/7f
            val bottomWeight=r/7f
            if (p.color==PieceColor.WHITE) {
                whiteTop += topWeight; whiteBottom += bottomWeight
            } else {
                blackTop += topWeight; blackBottom += bottomWeight
            }
        }

        val whiteBottomScore = whiteBottom + blackTop
        val blackBottomScore = blackBottom + whiteTop
        val delta = whiteBottomScore-blackBottomScore

        return when {
            delta > 1.2f -> Orientation.WHITE_BOTTOM
            delta < -1.2f -> Orientation.BLACK_BOTTOM
            else -> Orientation.UNKNOWN
        }
    }
}
