package com.ramin.chessassistant

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.*
import android.media.ImageReader
import android.media.projection.*
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private val detector = BoardDetector()
    private lateinit var tracker: PositionTracker
    private val busy = AtomicBoolean(false)
    private var lastAnalyze = 0L

    private var candidateBoardFen: String? = null
    private var candidateCount = 0
    private var acceptedBoardFen: String? = null
    private var sideToMove = "w"
    private var sequence = 0L
    private var frameW = 0
    private var frameH = 0
    private var initialSideToMove: String? = null

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"

        const val ACTION_POSITION = "com.ramin.chessassistant.POSITION"
        const val E_FOUND = "found"
        const val E_L = "l"
        const val E_T = "t"
        const val E_R = "r"
        const val E_B = "b"
        const val E_ORIENTATION = "orientation"
        const val E_FEN = "fen"
        const val E_SEQ = "seq"
        const val E_STATUS = "status"
        // Size of the captured frame the rect is expressed in (needed for overlay mapping).
        const val E_FW = "fw"
        const val E_FH = "fh"

        private const val CH = "capture"
        private const val ID = 1001
        private const val ANALYZE_INTERVAL_MS = 500L
    }

    override fun onCreate() {
        super.onCreate()

        val prefs = getSharedPreferences("assistant", MODE_PRIVATE)
        val my = prefs.getString("my_color", "w") ?: "w"
        val myColor = if (my == "b") PieceColor.BLACK else PieceColor.WHITE
        val orientation =
            if (myColor == PieceColor.WHITE) Orientation.WHITE_BOTTOM else Orientation.BLACK_BOTTOM

        // "start"  = M4.1 behaviour (standard initial position, white to move)
        // "screen" = recognise the current screenshot (arbitrary position)
        val initializer: PositionInitializer =
            if (prefs.getString("init_mode", "start") == "screen") {
                val stm = prefs.getString("initial_stm", "w") ?: "w"
                RecognitionInitializer(TemplatePieceRecognizer(this), orientation, stm)
            } else {
                StartPositionInitializer(orientation)
            }

        sideToMove = "w"
        tracker = PositionTracker(myColor, initializer)
        thread = HandlerThread("ChessVision").also { it.start() }
        handler = Handler(thread!!.looper)

        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CH, "Screen capture", NotificationManager.IMPORTANCE_LOW)
        )

        val n = Notification.Builder(this, CH)
            .setContentTitle("Chess Assistant")
            .setContentText("Vision + Stockfish pipeline active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(ID, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED

        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = pm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)

        reader = ImageReader.newInstance(
            m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2
        )

        reader?.setOnImageAvailableListener({ ir ->
            val now = System.currentTimeMillis()
            if (now - lastAnalyze < ANALYZE_INTERVAL_MS || busy.get()) {
                ir.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy.set(true)
            lastAnalyze = now

            try {
                val p = image.planes[0]
                val pad = p.rowStride - p.pixelStride * image.width
                val padded = Bitmap.createBitmap(
                    image.width + pad / p.pixelStride,
                    image.height,
                    Bitmap.Config.ARGB_8888
                )
                padded.copyPixelsFromBuffer(p.buffer)
                val bm = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                padded.recycle()
                frameW = bm.width
                frameH = bm.height

                val board = detector.detect(bm)
                if (board == null) {
                    broadcast(null, null, "NO BOARD")
                } else {
                    val tracked = tracker.update(bm, board.rect)
                    if (tracked.sideToMove != null) initialSideToMove = tracked.sideToMove

                    // The tracker reports accepted=true only once per change; the following
                    // "no change" frames (same boardFen) are what confirm it.
                    val confirming = !tracked.accepted &&
                        tracked.boardFen.isNotEmpty() &&
                        tracked.boardFen == candidateBoardFen

                    if (tracked.accepted || confirming) {
                        stabilizeTrackedAndBroadcast(board, tracked)
                    } else {
                        broadcast(board, null, tracked.status)
                    }
                }

                bm.recycle()
            } catch (_: Throwable) {
                broadcast(null, null, "VISION ERROR")
            } finally {
                image.close()
                busy.set(false)
            }
        }, handler)

        display = projection?.createVirtualDisplay(
            "ChessAssistant",
            m.widthPixels,
            m.heightPixels,
            m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface,
            null,
            handler
        )

        return START_NOT_STICKY
    }

    private fun stabilizeTrackedAndBroadcast(
        board: BoardGeometry,
        tracked: PositionTracker.Update
    ) {
        if (candidateBoardFen == tracked.boardFen) {
            candidateCount++
        } else {
            candidateBoardFen = tracked.boardFen
            candidateCount = 1
        }

        if (candidateCount < 2) {
            broadcast(board, null, "VERIFYING TRACKED POSITION…")
            return
        }

        if (acceptedBoardFen != tracked.boardFen) {
            if (acceptedBoardFen != null) {
                sideToMove = if (sideToMove == "w") "b" else "w"
            } else {
                // First accepted position: take side to move from the initializer.
                sideToMove = initialSideToMove ?: "w"
            }
            acceptedBoardFen = tracked.boardFen
            sequence++
        }

        val fullFen = "${tracked.boardFen} $sideToMove - - 0 1"
        val orient = if (tracked.orientation == Orientation.WHITE_BOTTOM) "W" else "B"
        broadcast(board, Triple(fullFen, orient, sequence), tracked.status)
    }

    private fun broadcast(
        board: BoardGeometry?,
        state: Triple<String, String, Long>?,
        status: String
    ) {
        val i = Intent(ACTION_POSITION).setPackage(packageName)
        i.putExtra(E_FOUND, board != null)
        i.putExtra(E_STATUS, status)
        i.putExtra(E_FW, frameW)
        i.putExtra(E_FH, frameH)

        board?.rect?.let {
            i.putExtra(E_L, it.left)
            i.putExtra(E_T, it.top)
            i.putExtra(E_R, it.right)
            i.putExtra(E_B, it.bottom)
        }

        state?.let {
            i.putExtra(E_FEN, it.first)
            i.putExtra(E_ORIENTATION, it.second)
            i.putExtra(E_SEQ, it.third)
        }

        sendBroadcast(i)
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
