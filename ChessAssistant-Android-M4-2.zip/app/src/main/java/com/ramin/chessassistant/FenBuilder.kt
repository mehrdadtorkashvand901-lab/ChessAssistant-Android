package com.ramin.chessassistant

class FenBuilder {
    fun build(screenGrid: Array<Array<Piece?>>, orientation: Orientation): String {
        val board = Array(8) { arrayOfNulls<Piece>(8) }

        for (sr in 0..7) for (sf in 0..7) {
            val p = screenGrid[sr][sf] ?: continue
            when (orientation) {
                Orientation.WHITE_BOTTOM -> {
                    board[sr][sf] = p
                }
                Orientation.BLACK_BOTTOM -> {
                    board[7-sr][7-sf] = p
                }
                Orientation.UNKNOWN -> {
                    board[sr][sf] = p
                }
            }
        }

        val ranks = board.map { row ->
            val sb=StringBuilder()
            var empty=0
            for (p in row) {
                if (p==null) empty++
                else {
                    if (empty>0) { sb.append(empty); empty=0 }
                    val ch=p.type.fen
                    sb.append(if (p.color==PieceColor.WHITE) ch.uppercaseChar() else ch)
                }
            }
            if (empty>0) sb.append(empty)
            sb.toString()
        }
        return ranks.joinToString("/")
    }
}
