package com.ramin.chessassistant

/**
 * Authoritative chess position: board, side to move, castling rights, en-passant square
 * and move clocks. Immutable — apply() returns a new state.
 *
 * Square index: sq = row * 8 + col, row 0 = rank 8, col 0 = file a
 * (same layout FenBuilder writes).
 */
class ChessState private constructor(
    private val board: Array<Piece?>,
    val sideToMove: PieceColor,
    /** bit 1 = K, 2 = Q, 4 = k, 8 = q */
    val castling: Int,
    /** en-passant target square or -1 */
    val epSquare: Int,
    val halfmove: Int,
    val fullmove: Int
) {
    data class Move(
        val from: Int,
        val to: Int,
        val promotion: PieceType? = null,
        val isCastle: Boolean = false,
        val isEnPassant: Boolean = false
    ) {
        fun uci(): String = sqName(from) + sqName(to) + (promotion?.fen?.toString() ?: "")

        /** Every square whose visual content changes when this move is played. */
        fun touched(): Set<Int> {
            val s = mutableSetOf(from, to)
            if (isEnPassant) s += (from / 8) * 8 + (to % 8)
            if (isCastle) {
                val row = from / 8
                if (to % 8 == 6) { s += row * 8 + 7; s += row * 8 + 5 }
                else { s += row * 8 + 0; s += row * 8 + 3 }
            }
            return s
        }
    }

    operator fun get(sq: Int): Piece? = board[sq]

    fun kingSquare(color: PieceColor): Int =
        board.indices.firstOrNull { board[it]?.let { p -> p.color == color && p.type == PieceType.KING } == true } ?: -1

    fun inCheck(color: PieceColor = sideToMove): Boolean {
        val k = kingSquare(color)
        return k >= 0 && isAttacked(k, color.other())
    }

    // ---------------------------------------------------------------- FEN

    fun boardFen(): String {
        val sb = StringBuilder()
        for (r in 0..7) {
            var empty = 0
            for (c in 0..7) {
                val p = board[r * 8 + c]
                if (p == null) { empty++; continue }
                if (empty > 0) { sb.append(empty); empty = 0 }
                sb.append(if (p.color == PieceColor.WHITE) p.type.fen.uppercaseChar() else p.type.fen)
            }
            if (empty > 0) sb.append(empty)
            if (r < 7) sb.append('/')
        }
        return sb.toString()
    }

    fun toFen(): String {
        val c = buildString {
            if (castling and 1 != 0) append('K')
            if (castling and 2 != 0) append('Q')
            if (castling and 4 != 0) append('k')
            if (castling and 8 != 0) append('q')
        }.ifEmpty { "-" }
        val ep = if (epSquare >= 0) sqName(epSquare) else "-"
        val stm = if (sideToMove == PieceColor.WHITE) "w" else "b"
        return "${boardFen()} $stm $c $ep $halfmove $fullmove"
    }

    /** Screen grid (row 0 = top of screen) for the given orientation. */
    fun toScreenGrid(orientation: Orientation): Array<Array<Piece?>> =
        Array(8) { sr -> Array(8) { sf -> board[screenToSquare(sr, sf, orientation)] } }

    // ---------------------------------------------------------- move generation

    fun legalMoves(): List<Move> {
        val out = ArrayList<Move>(48)
        val me = sideToMove
        for (sq in 0..63) {
            val p = board[sq] ?: continue
            if (p.color != me) continue
            when (p.type) {
                PieceType.PAWN -> pawnMoves(sq, out)
                PieceType.KNIGHT -> stepMoves(sq, KNIGHT, out)
                PieceType.KING -> { stepMoves(sq, KING, out); castleMoves(sq, out) }
                PieceType.BISHOP -> slideMoves(sq, DIAG, out)
                PieceType.ROOK -> slideMoves(sq, ORTHO, out)
                PieceType.QUEEN -> { slideMoves(sq, DIAG, out); slideMoves(sq, ORTHO, out) }
            }
        }
        return out.filter { m -> !apply(m).let { it.isAttacked(it.kingSquare(me), me.other()) } }
    }

    fun apply(m: Move): ChessState {
        val b = board.copyOf()
        val moving = b[m.from]!!
        val captured = b[m.to]
        b[m.to] = if (m.promotion != null) Piece(moving.color, m.promotion) else moving
        b[m.from] = null
        if (m.isEnPassant) b[(m.from / 8) * 8 + (m.to % 8)] = null
        if (m.isCastle) {
            val row = m.from / 8
            if (m.to % 8 == 6) { b[row * 8 + 5] = b[row * 8 + 7]; b[row * 8 + 7] = null }
            else { b[row * 8 + 3] = b[row * 8 + 0]; b[row * 8 + 0] = null }
        }

        var c = castling
        c = c and CASTLE_MASK[m.from] and CASTLE_MASK[m.to]

        val ep = if (moving.type == PieceType.PAWN && kotlin.math.abs(m.to - m.from) == 16)
            (m.from + m.to) / 2 else -1
        val half = if (moving.type == PieceType.PAWN || captured != null || m.isEnPassant) 0 else halfmove + 1
        val full = if (sideToMove == PieceColor.BLACK) fullmove + 1 else fullmove

        return ChessState(b, sideToMove.other(), c, ep, half, full)
    }

    fun isAttacked(sq: Int, by: PieceColor): Boolean {
        if (sq < 0) return false
        val r = sq / 8; val c = sq % 8
        // Pawns: a white pawn attacks toward row - 1, so it sits on row + 1.
        val pr = if (by == PieceColor.WHITE) r + 1 else r - 1
        for (dc in intArrayOf(-1, 1)) {
            if (isAt(pr, c + dc, by, PieceType.PAWN)) return true
        }
        for ((dr, dc) in KNIGHT) if (isAt(r + dr, c + dc, by, PieceType.KNIGHT)) return true
        for ((dr, dc) in KING) if (isAt(r + dr, c + dc, by, PieceType.KING)) return true
        for ((dr, dc) in ORTHO) if (rayHits(r, c, dr, dc, by, PieceType.ROOK)) return true
        for ((dr, dc) in DIAG) if (rayHits(r, c, dr, dc, by, PieceType.BISHOP)) return true
        return false
    }

    private fun isAt(r: Int, c: Int, color: PieceColor, type: PieceType): Boolean {
        if (r !in 0..7 || c !in 0..7) return false
        val p = board[r * 8 + c] ?: return false
        return p.color == color && p.type == type
    }

    private fun rayHits(r0: Int, c0: Int, dr: Int, dc: Int, by: PieceColor, slider: PieceType): Boolean {
        var r = r0 + dr; var c = c0 + dc
        while (r in 0..7 && c in 0..7) {
            val p = board[r * 8 + c]
            if (p != null) return p.color == by && (p.type == slider || p.type == PieceType.QUEEN)
            r += dr; c += dc
        }
        return false
    }

    private fun pawnMoves(sq: Int, out: MutableList<Move>) {
        val me = board[sq]!!.color
        val r = sq / 8; val c = sq % 8
        val dir = if (me == PieceColor.WHITE) -1 else 1
        val startRow = if (me == PieceColor.WHITE) 6 else 1
        val promoRow = if (me == PieceColor.WHITE) 0 else 7

        fun add(to: Int, ep: Boolean = false) {
            if (to / 8 == promoRow) {
                for (t in PROMOS) out += Move(sq, to, promotion = t)
            } else out += Move(sq, to, isEnPassant = ep)
        }

        val r1 = r + dir
        if (r1 in 0..7 && board[r1 * 8 + c] == null) {
            add(r1 * 8 + c)
            val r2 = r + 2 * dir
            if (r == startRow && board[r2 * 8 + c] == null) out += Move(sq, r2 * 8 + c)
        }
        for (dc in intArrayOf(-1, 1)) {
            val cc = c + dc
            if (r1 !in 0..7 || cc !in 0..7) continue
            val to = r1 * 8 + cc
            val t = board[to]
            if (t != null && t.color != me) add(to)
            else if (to == epSquare) add(to, ep = true)
        }
    }

    private fun stepMoves(sq: Int, deltas: Array<Pair<Int, Int>>, out: MutableList<Move>) {
        val me = board[sq]!!.color
        val r = sq / 8; val c = sq % 8
        for ((dr, dc) in deltas) {
            val rr = r + dr; val cc = c + dc
            if (rr !in 0..7 || cc !in 0..7) continue
            val t = board[rr * 8 + cc]
            if (t == null || t.color != me) out += Move(sq, rr * 8 + cc)
        }
    }

    private fun slideMoves(sq: Int, dirs: Array<Pair<Int, Int>>, out: MutableList<Move>) {
        val me = board[sq]!!.color
        val r0 = sq / 8; val c0 = sq % 8
        for ((dr, dc) in dirs) {
            var r = r0 + dr; var c = c0 + dc
            while (r in 0..7 && c in 0..7) {
                val t = board[r * 8 + c]
                if (t == null) out += Move(sq, r * 8 + c)
                else { if (t.color != me) out += Move(sq, r * 8 + c); break }
                r += dr; c += dc
            }
        }
    }

    private fun castleMoves(sq: Int, out: MutableList<Move>) {
        val me = board[sq]!!.color
        val row = if (me == PieceColor.WHITE) 7 else 0
        if (sq != row * 8 + 4) return
        val kBit = if (me == PieceColor.WHITE) 1 else 4
        val qBit = if (me == PieceColor.WHITE) 2 else 8
        val them = me.other()
        if (isAttacked(sq, them)) return
        fun rookAt(col: Int) = board[row * 8 + col].let { it != null && it.color == me && it.type == PieceType.ROOK }

        if (castling and kBit != 0 && rookAt(7) &&
            board[row * 8 + 5] == null && board[row * 8 + 6] == null &&
            !isAttacked(row * 8 + 5, them) && !isAttacked(row * 8 + 6, them)
        ) out += Move(sq, row * 8 + 6, isCastle = true)

        if (castling and qBit != 0 && rookAt(0) &&
            board[row * 8 + 1] == null && board[row * 8 + 2] == null && board[row * 8 + 3] == null &&
            !isAttacked(row * 8 + 3, them) && !isAttacked(row * 8 + 2, them)
        ) out += Move(sq, row * 8 + 2, isCastle = true)
    }

    companion object {
        private val KNIGHT = arrayOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1)
        private val KING = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1, 1 to 1, 1 to -1, -1 to 1, -1 to -1)
        private val ORTHO = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
        private val DIAG = arrayOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
        private val PROMOS = arrayOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

        /** Moving from / to these squares clears the matching castling rights. */
        private val CASTLE_MASK = IntArray(64) { 15 }.also {
            it[7 * 8 + 4] = 15 and 1.inv() and 2.inv()   // e1
            it[7 * 8 + 7] = 15 and 1.inv()               // h1
            it[7 * 8 + 0] = 15 and 2.inv()               // a1
            it[0 * 8 + 4] = 15 and 4.inv() and 8.inv()   // e8
            it[0 * 8 + 7] = 15 and 4.inv()               // h8
            it[0 * 8 + 0] = 15 and 8.inv()               // a8
        }

        fun sqName(sq: Int): String = "${'a' + sq % 8}${8 - sq / 8}"

        fun screenToSquare(screenRow: Int, screenCol: Int, orientation: Orientation): Int =
            if (orientation == Orientation.BLACK_BOTTOM) (7 - screenRow) * 8 + (7 - screenCol)
            else screenRow * 8 + screenCol

        fun initial(): ChessState = fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")!!

        /**
         * Position read from the screen. Castling rights are inferred from king/rook home
         * squares (the only information a static board offers); en passant is unknown.
         */
        fun fromScreenGrid(screen: Array<Array<Piece?>>, orientation: Orientation, stm: PieceColor): ChessState {
            val b = arrayOfNulls<Piece>(64)
            for (sr in 0..7) for (sf in 0..7) b[screenToSquare(sr, sf, orientation)] = screen[sr][sf]
            fun has(sq: Int, color: PieceColor, t: PieceType) = b[sq]?.let { it.color == color && it.type == t } == true
            var c = 0
            if (has(60, PieceColor.WHITE, PieceType.KING)) {
                if (has(63, PieceColor.WHITE, PieceType.ROOK)) c = c or 1
                if (has(56, PieceColor.WHITE, PieceType.ROOK)) c = c or 2
            }
            if (has(4, PieceColor.BLACK, PieceType.KING)) {
                if (has(7, PieceColor.BLACK, PieceType.ROOK)) c = c or 4
                if (has(0, PieceColor.BLACK, PieceType.ROOK)) c = c or 8
            }
            return ChessState(b, stm, c, -1, 0, 1)
        }

        fun fromFen(fen: String): ChessState? {
            val parts = fen.trim().split(Regex("\\s+"))
            if (parts.size < 2) return null
            val b = arrayOfNulls<Piece>(64)
            var sq = 0
            for (ch in parts[0]) {
                when {
                    ch == '/' -> continue
                    ch.isDigit() -> sq += ch - '0'
                    else -> {
                        val type = PieceType.values().firstOrNull { it.fen == ch.lowercaseChar() } ?: return null
                        if (sq > 63) return null
                        b[sq++] = Piece(if (ch.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK, type)
                    }
                }
            }
            if (sq != 64) return null
            val stm = if (parts[1] == "b") PieceColor.BLACK else PieceColor.WHITE
            var c = 0
            parts.getOrNull(2)?.forEach {
                when (it) { 'K' -> c = c or 1; 'Q' -> c = c or 2; 'k' -> c = c or 4; 'q' -> c = c or 8 }
            }
            val ep = parts.getOrNull(3)?.takeIf { it.length == 2 && it[0] in 'a'..'h' && it[1] in '1'..'8' }
                ?.let { (8 - (it[1] - '0')) * 8 + (it[0] - 'a') } ?: -1
            val half = parts.getOrNull(4)?.toIntOrNull() ?: 0
            val full = parts.getOrNull(5)?.toIntOrNull() ?: 1
            return ChessState(b, stm, c, ep, half, full)
        }
    }
}

fun PieceColor.other(): PieceColor =
    if (this == PieceColor.WHITE) PieceColor.BLACK else PieceColor.WHITE
