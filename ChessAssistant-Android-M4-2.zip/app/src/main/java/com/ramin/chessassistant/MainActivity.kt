package com.ramin.chessassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView

    private val capture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            val i = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, r.resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, r.data)
            }
            ContextCompat.startForegroundService(this, i)
            startService(Intent(this, OverlayService::class.java))
            status.text = "Running — my color only / Stockfish 18 Lite / 500 ms"
        } else {
            status.text = "Capture denied"
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        val prefs = getSharedPreferences("assistant", MODE_PRIVATE)

        status = TextView(this).apply {
            text = "Stopped"
            textSize = 18f
            gravity = Gravity.CENTER
        }

        val sideLabel = TextView(this).apply {
            text = "My color:"
            gravity = Gravity.CENTER
        }

        val sideGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val white = RadioButton(this).apply {
            id = 1001
            text = "White"
        }
        val black = RadioButton(this).apply {
            id = 1002
            text = "Black"
        }

        sideGroup.addView(white)
        sideGroup.addView(black)

        if (prefs.getString("my_color", "w") == "b") black.isChecked = true
        else white.isChecked = true

        sideGroup.setOnCheckedChangeListener { _, id ->
            prefs.edit()
                .putString("my_color", if (id == 1002) "b" else "w")
                .apply()
        }

        val info = TextView(this).apply {
            text = "M4 — live board recognition → FEN → Stockfish → move arrow"
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply { text = "START ASSISTANT" }
        val stop = Button(this).apply { text = "STOP ASSISTANT" }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(38, 38, 38, 38)
            addView(info)
            addView(sideLabel)
            addView(sideGroup)
            addView(status)
            addView(start)
            addView(stop)
        })

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                status.text = "Enable overlay, then tap START again"
            } else {
                val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                capture.launch(m.createScreenCaptureIntent())
            }
        }

        stop.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            stopService(Intent(this, OverlayService::class.java))
            status.text = "Stopped"
        }
    }
}
