package com.ramin.chessassistant

import kotlin.math.abs

class PositionValidator {
    data class Result(val ok:Boolean,val reason:String)

    /** Orientation-independent checks on a SCREEN grid (rows 0 and 7 are back ranks either way). */
    fun validate(grid:Array<Array<Piece?>>):Result {
        var wk=0; var bk=0; var wp=0; var bp=0
        var wPawns=0; var bPawns=0
        var wkPos=-1 to -1; var bkPos=-1 to -1
        for (r in 0..7) for (f in 0..7) {
            val p = grid[r][f] ?: continue
            if (p.type == PieceType.PAWN && (r == 0 || r == 7)) {
                return Result(false, "pawn on back rank")
            }
            if (p.color==PieceColor.WHITE) {
                wp++
                if (p.type==PieceType.KING) { wk++; wkPos = r to f }
                if (p.type==PieceType.PAWN) wPawns++
            } else {
                bp++
                if (p.type==PieceType.KING) { bk++; bkPos = r to f }
                if (p.type==PieceType.PAWN) bPawns++
            }
        }
        if (wk!=1) return Result(false,"white king count=$wk")
        if (bk!=1) return Result(false,"black king count=$bk")
        if (wp>16) return Result(false,"too many white pieces")
        if (bp>16) return Result(false,"too many black pieces")
        if (wPawns>8) return Result(false,"too many white pawns")
        if (bPawns>8) return Result(false,"too many black pawns")
        if (abs(wkPos.first-bkPos.first)<=1 && abs(wkPos.second-bkPos.second)<=1) {
            return Result(false,"kings adjacent")
        }
        return Result(true,"ok")
    }
}
