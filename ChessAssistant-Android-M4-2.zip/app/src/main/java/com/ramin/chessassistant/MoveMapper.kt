package com.ramin.chessassistant

import android.graphics.PointF
import android.graphics.Rect

object MoveMapper {
    data class Arrow(val from: PointF, val to: PointF)

    fun map(uci: String, board: Rect, orientation: Orientation): Arrow? {
        if (!Regex("^[a-h][1-8][a-h][1-8][qrbn]?$").matches(uci)) return null

        fun squareCenter(fileChar: Char, rankChar: Char): PointF {
            val file = fileChar - 'a'
            val rank = rankChar - '1'
            val cell = board.width() / 8f

            val col: Int
            val row: Int

            if (orientation == Orientation.BLACK_BOTTOM) {
                col = 7 - file
                row = rank
            } else {
                col = file
                row = 7 - rank
            }

            return PointF(
                board.left + (col + 0.5f) * cell,
                board.top + (row + 0.5f) * cell
            )
        }

        return Arrow(
            squareCenter(uci[0], uci[1]),
            squareCenter(uci[2], uci[3])
        )
    }
}
