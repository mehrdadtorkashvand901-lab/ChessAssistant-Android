package com.ramin.chessassistant

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class BoardOverlayView(context: Context) : View(context) {
    private val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x9900FF00.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD54F.toInt()
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 13f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 27f
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    private var board: Rect? = null
    private var status = ""
    private var move: String? = null
    private var orientation = Orientation.UNKNOWN

    fun updateBoard(rect: Rect?, text: String, orientation: Orientation) {
        board = rect?.let { Rect(it) }
        status = text
        this.orientation = orientation
        invalidate()
    }

    fun updateMove(uci: String?) {
        move = uci
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val r = board ?: return

        val left = r.left.toFloat()
        val top = r.top.toFloat()
        val size = r.width().toFloat()
        val cell = size / 8f

        // Exact outer playable-board boundary.
        canvas.drawRect(left, top, left + size, top + size, boardPaint)

        // Exact 1/8 boundaries derived from one shared float cell size.
        // This avoids accumulated integer rounding drift.
        for (i in 1 until 8) {
            val x = left + i * cell
            val y = top + i * cell
            canvas.drawLine(x, top, x, top + size, boardPaint)
            canvas.drawLine(left, y, left + size, y, boardPaint)
        }

        canvas.drawText(
            status,
            left,
            (r.top - 12).coerceAtLeast(35).toFloat(),
            textPaint
        )

        val uci = move ?: return
        val arrow = MoveMapper.map(uci, r, orientation) ?: return
        drawArrow(canvas, arrow.from, arrow.to)
    }

    private fun drawArrow(canvas: Canvas, from: PointF, to: PointF) {
        canvas.drawLine(from.x, from.y, to.x, to.y, arrowPaint)

        val angle = atan2(to.y - from.y, to.x - from.x)
        val head = 34f
        val spread = 0.55f

        val p1 = PointF(
            to.x - head * cos(angle - spread),
            to.y - head * sin(angle - spread)
        )
        val p2 = PointF(
            to.x - head * cos(angle + spread),
            to.y - head * sin(angle + spread)
        )

        canvas.drawLine(to.x, to.y, p1.x, p1.y, arrowPaint)
        canvas.drawLine(to.x, to.y, p2.x, p2.y, arrowPaint)
    }
}
