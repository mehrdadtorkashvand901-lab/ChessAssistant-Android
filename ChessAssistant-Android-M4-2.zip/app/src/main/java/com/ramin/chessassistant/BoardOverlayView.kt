package com.ramin.chessassistant

import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

class BoardOverlayView(context: Context) : View(context) {
    // Size of the MediaProjection frame that board rects are expressed in.
    private var frameW = 0
    private var frameH = 0
    private val loc = IntArray(2)

    init {
        // Window origin can change after insets/cutout/rotation are applied.
        addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> invalidate() }
    }

    fun setFrameSize(w: Int, h: Int) {
        frameW = w
        frameH = h
    }

    /** Physical display size in px — the coordinate space MediaProjection mirrors. */
    private fun realDisplaySize(): Point {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = context.getSystemService(WindowManager::class.java)
                .maximumWindowMetrics.bounds
            return Point(b.width(), b.height())
        }
        val p = Point()
        @Suppress("DEPRECATION")
        display?.getRealSize(p)
        return p
    }

    /**
     * capture-frame px  ->  display px  ->  this view's local px
     *
     *   displayX = frameX * displayW / frameW
     *   viewX    = displayX - viewOriginOnScreenX
     *
     * viewOriginOnScreen already contains whatever the system did with the status bar,
     * display cutout, navigation bar and WindowInsets, so no inset is hard-coded.
     */
    private fun frameRectToView(src: Rect): Rect {
        val disp = realDisplaySize()
        val sx = if (frameW > 0 && disp.x > 0) disp.x.toFloat() / frameW else 1f
        val sy = if (frameH > 0 && disp.y > 0) disp.y.toFloat() / frameH else 1f
        getLocationOnScreen(loc)

        val left = (src.left * sx - loc[0]).roundToInt()
        val top = (src.top * sy - loc[1]).roundToInt()
        val size = (src.width() * sx).roundToInt() // board stays square
        return Rect(left, top, left + size, top + size)
    }

    private fun scaleMismatch(): Boolean {
        if (frameW <= 0 || frameH <= 0) return false
        val d = realDisplaySize()
        if (d.x <= 0 || d.y <= 0) return false
        return abs(d.x.toFloat() / frameW - d.y.toFloat() / frameH) > 0.01f
    }

    private val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x9900FF00.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD54F.toInt()
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 13f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 27f
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    private var board: Rect? = null
    private var status = ""
    private var move: String? = null
    private var orientation = Orientation.UNKNOWN

    fun updateBoard(rect: Rect?, text: String, orientation: Orientation) {
        board = rect?.let { Rect(it) }
        status = text
        this.orientation = orientation
        invalidate()
    }

    fun updateMove(uci: String?) {
        move = uci
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        // board is in capture-frame coordinates; draw in view coordinates.
        val r = frameRectToView(board ?: return)
        if (scaleMismatch()) {
            // Capture buffer aspect != display aspect (e.g. rotated after projection start):
            // the mirrored image is letterboxed and a plain scale is wrong.
            canvas.drawText("CAPTURE/DISPLAY ASPECT MISMATCH — restart capture", 20f, 60f, textPaint)
            return
        }

        val left = r.left.toFloat()
        val top = r.top.toFloat()
        val size = r.width().toFloat()
        val cell = size / 8f

        // Exact outer playable-board boundary.
        canvas.drawRect(left, top, left + size, top + size, boardPaint)

        // Exact 1/8 boundaries derived from one shared float cell size.
        // This avoids accumulated integer rounding drift.
        for (i in 1 until 8) {
            val x = left + i * cell
            val y = top + i * cell
            canvas.drawLine(x, top, x, top + size, boardPaint)
            canvas.drawLine(left, y, left + size, y, boardPaint)
        }

        canvas.drawText(
            status,
            left,
            (r.top - 12).coerceAtLeast(35).toFloat(),
            textPaint
        )

        val uci = move ?: return
        val arrow = MoveMapper.map(uci, r, orientation) ?: return
        drawArrow(canvas, arrow.from, arrow.to)
    }

    private fun drawArrow(canvas: Canvas, from: PointF, to: PointF) {
        canvas.drawLine(from.x, from.y, to.x, to.y, arrowPaint)

        val angle = atan2(to.y - from.y, to.x - from.x)
        val head = 34f
        val spread = 0.55f

        val p1 = PointF(
            to.x - head * cos(angle - spread),
            to.y - head * sin(angle - spread)
        )
        val p2 = PointF(
            to.x - head * cos(angle + spread),
            to.y - head * sin(angle + spread)
        )

        canvas.drawLine(to.x, to.y, p1.x, p1.y, arrowPaint)
        canvas.drawLine(to.x, to.y, p2.x, p2.y, arrowPaint)
    }
}
