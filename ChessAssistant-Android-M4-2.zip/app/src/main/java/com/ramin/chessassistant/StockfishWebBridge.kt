package com.ramin.chessassistant

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class StockfishWebBridge(
    context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onEngineReady()
        fun onBestMove(requestId: String, move: String)
        fun onEngineError(message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var ready = false

    @SuppressLint("SetJavaScriptEnabled")
    private val webView = WebView(context.applicationContext).apply {
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = false
        settings.domStorageEnabled = false
        addJavascriptInterface(BridgeApi(), "AndroidEngine")
        webViewClient = WebViewClient()
        loadUrl("file:///android_asset/engine_host.html")
    }

    private inner class BridgeApi {
        @JavascriptInterface
        fun onEngineReady() {
            main.post {
                ready = true
                listener.onEngineReady()
            }
        }

        @JavascriptInterface
        fun onBestMove(requestId: String, move: String) {
            main.post { listener.onBestMove(requestId, move) }
        }

        @JavascriptInterface
        fun onEngineError(message: String) {
            main.post { listener.onEngineError(message) }
        }
    }

    fun analyze(requestId: String, fen: String, moveTimeMs: Int = 500) {
        if (!ready) return
        val idJson = JSONObject.quote(requestId)
        val fenJson = JSONObject.quote(fen)
        webView.evaluateJavascript(
            "window.analyzeFen($idJson,$fenJson,$moveTimeMs);",
            null
        )
    }

    fun stop() {
        if (!ready) return
        webView.evaluateJavascript("window.stopEngineSearch();", null)
    }

    fun destroy() {
        stop()
        webView.removeJavascriptInterface("AndroidEngine")
        webView.destroy()
        ready = false
    }
}
