package com.ramin.chessassistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max

class TemplatePieceRecognizer(private val context: Context) {
    private data class T(val piece: Piece, val desc: FloatArray)
    private val templates = mutableListOf<T>()

    init {
        val names = context.assets.list("templates")?.toList().orEmpty()
        for (name in names) {
            val piece = pieceFromName(name) ?: continue
            context.assets.open("templates/$name").use { input ->
                val bm = BitmapFactory.decodeStream(input)
                templates += T(piece, descriptor(bm))
                bm.recycle()
            }
        }
    }

    fun recognize(frame: Bitmap, board: Rect): Recognition {
        val grid = Array(8) { arrayOfNulls<Piece>(8) }
        val conf = Array(8) { FloatArray(8) }
        val cell = board.width() / 8f

        for (r in 0..7) for (f in 0..7) {
            val x0 = (board.left + f*cell).toInt()
            val y0 = (board.top + r*cell).toInt()
            val x1 = (board.left + (f+1)*cell).toInt().coerceAtMost(frame.width)
            val y1 = (board.top + (r+1)*cell).toInt().coerceAtMost(frame.height)

            val crop = Bitmap.createBitmap(frame, x0, y0, max(1,x1-x0), max(1,y1-y0))
            val d = descriptor(crop)
            crop.recycle()

            val emptyScore = foregroundEnergy(d)
            if (emptyScore < 0.095f) {
                grid[r][f] = null
                conf[r][f] = (1f - emptyScore / 0.095f).coerceIn(0f,1f)
                continue
            }

            var best: T? = null
            var bestDist = Float.MAX_VALUE
            var second = Float.MAX_VALUE
            for (t in templates) {
                val dist = l1(d,t.desc)
                if (dist < bestDist) {
                    second = bestDist
                    bestDist = dist
                    best = t
                } else if (dist < second) second = dist
            }

            val separation = if (second.isFinite() && second > 0f)
                ((second-bestDist)/second).coerceIn(0f,1f) else 0f

            if (best != null && bestDist < 0.34f && separation > 0.035f) {
                grid[r][f] = best.piece
                conf[r][f] = (1f-bestDist/0.34f).coerceIn(0f,1f) * .7f + separation*.3f
            } else {
                grid[r][f] = null
                conf[r][f] = 0f
            }
        }

        val orientation = OrientationDetector().detect(grid)
        val fen = FenBuilder().build(grid, orientation)
        val vr = PositionValidator().validate(grid)
        return Recognition(grid,conf,orientation,fen,vr.ok,vr.reason)
    }

    private fun pieceFromName(name: String): Piece? {
        val key = name.substringBefore("_")
        val color = if (key.startsWith("w")) PieceColor.WHITE else PieceColor.BLACK
        val type = when (key.drop(1)) {
            "P" -> PieceType.PAWN
            "N" -> PieceType.KNIGHT
            "B" -> PieceType.BISHOP
            "R" -> PieceType.ROOK
            "Q" -> PieceType.QUEEN
            "K" -> PieceType.KING
            else -> return null
        }
        return Piece(color,type)
    }

    private fun descriptor(src: Bitmap): FloatArray {
        val bm = Bitmap.createScaledBitmap(src,48,48,true)
        val corner = floatArrayOf(
            luma(bm.getPixel(2,2)), luma(bm.getPixel(45,2)),
            luma(bm.getPixel(2,45)), luma(bm.getPixel(45,45))
        ).average().toFloat()

        val out = FloatArray(24*24)
        var k=0
        for (y in 0 until 24) for (x in 0 until 24) {
            val xx=x*2+1; val yy=y*2+1
            val lum=luma(bm.getPixel(xx,yy))
            out[k++] = (abs(lum-corner)/255f).coerceIn(0f,1f)
        }
        if (bm !== src) bm.recycle()
        return out
    }

    private fun foregroundEnergy(d: FloatArray): Float = d.average().toFloat()

    private fun l1(a: FloatArray,b: FloatArray): Float {
        var s=0f
        for (i in a.indices) s += abs(a[i]-b[i])
        return s/a.size
    }

    private fun luma(c:Int):Float {
        val r=(c shr 16) and 255; val g=(c shr 8) and 255; val b=c and 255
        return .2126f*r + .7152f*g + .0722f*b
    }
}
