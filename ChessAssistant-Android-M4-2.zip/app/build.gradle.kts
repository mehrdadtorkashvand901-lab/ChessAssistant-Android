plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ramin.chessassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ramin.chessassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.4.2-m42"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
