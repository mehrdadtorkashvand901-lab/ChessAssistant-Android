# M4.4: authoritative chess state

Live-test finding: the overlay could stay on "BLACK to move", Stockfish never ran on the expected side, and no arrow appeared.

Root cause: `CaptureService` kept its own `sideToMove` and flipped it whenever the board FEN string changed. `PositionTracker` produced that FEN by guessing source and destination from the two most-changed squares, with no legality check. A highlight change, an animation frame or a popup could therefore count as a "move" and flip the turn. A real move rejected as ambiguous was lost for good, because the comparison baseline moved on every frame.

M4.4:
- `ChessState` holds the board, side to move, castling, en passant and clocks, with full legal move generation (perft-verified). It is the only source of truth.
- `PositionTracker` keeps a baseline from the last confirmed position. It only reads settled frames, and advances only when one legal move sequence (1–3 plies) explains the change. Highlight squares are tolerated, and a self-calibrating empty/white/black appearance check must agree.
- Otherwise nothing changes. A persistent mismatch shows OUT OF SYNC, which clears by itself when the board matches again.
- `CaptureService` no longer toggles anything. It forwards the tracker's FEN and version.
- `OverlayService` analyses only on your turn and only while in sync.
- Statuses: POSITION READY · WHITE TO MOVE · BLACK TO MOVE · ANALYZING · BESTMOVE … · OUT OF SYNC · CHECKMATE / STALEMATE.
- Capture interval changed from 500 ms to 200 ms, so fast replies still leave settled frames.

Retained: M4.3 overlay coordinate mapping (unchanged), screen/initial-position init, Stockfish 18 Lite.
