# M4.2 grid alignment fix

Live-test finding:
the green 8x8 overlay grid was slightly smaller / shifted compared with the actual
playable chessboard.

Root cause:
MediaProjection can capture at the device's native resolution while shared screenshots
can be scaled. The previous detector only used the calibrated rectangle for a narrow
pixel-size range, so on native capture it could fall back to the heuristic detector and
choose a slightly wrong board rectangle.

M4.2:
- uses normalized board coordinates for the target portrait UI
- works across scaled/native capture resolutions
- forces a square board rectangle
- derives all 8x8 lines from one float cell size to prevent rounding drift
- retains all M4.1 fixes:
  - My Color behavior
  - start-position initialization
  - changed-square move tracking
  - Stockfish only on the user's turn
