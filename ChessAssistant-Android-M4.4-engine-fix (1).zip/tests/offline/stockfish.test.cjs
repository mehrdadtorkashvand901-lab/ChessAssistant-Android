/* Runs the shipped HTML, loader and WASM without Android, a server or network.
 * VM contexts emulate the page and a Blob Worker; this is not a WebView test.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { test } = require('node:test');

const asset = process.env.ENGINE_HOST_PATH || path.join(__dirname,
  '../../app/src/main/assets/engine_host.html');
const html = fs.readFileSync(asset, 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

function harness() {
  const events = [], lines = [], requests = [], logs = [], blobs = new Map(), workers = [];
  const nativeWasm = WebAssembly;
  class OfflineWorker {
    constructor(url) {
      this.timers = new Set();
      this.queue = [];
      workers.push(this);
      const location = new URL(url);
      const sandbox = {
        location, onmessage: null, performance, TextDecoder, TextEncoder,
        atob, Response, Request, WebAssembly: nativeWasm,
        console: Object.fromEntries(['log', 'warn', 'error'].map(name =>
          [name, (...args) => logs.push(args.map(String).join(' '))])),
        importScripts() { throw new Error('Offline test forbids importScripts'); },
        XMLHttpRequest: class {
          open(method, target) { this.target = target; }
          send() {
            requests.push(['xhr', this.target]);
            throw new Error('offline XMLHttpRequest blocked: ' + this.target);
          }
        },
        postMessage: line => {
          lines.push(String(line));
          // Worker messages are asynchronous: callbacks must not re-enter WASM's
          // print routine before it has cleared its output buffer.
          queueMicrotask(() => { if (!this.closed) this.onmessage?.({ data: line }); });
        },
        setTimeout: (fn, ms) => {
          const timer = setTimeout(() => {
            this.timers.delete(timer);
            if (this.closed) return;
            try { fn(); } catch (error) { this.fail(error); }
          }, ms);
          this.timers.add(timer);
          return timer;
        },
        clearTimeout: timer => { clearTimeout(timer); this.timers.delete(timer); },
        close: () => this.terminate(),
      };
      sandbox.self = sandbox;
      this.context = vm.createContext(sandbox);
      blobs.get(url.split('#')[0]).text().then(source => {
        if (this.closed) return;
        try {
          vm.runInContext(source, this.context, { timeout: 5000 });
          // Record the loader's actual WASM URL without changing the fetch response.
          const embeddedFetch = this.context.fetch;
          this.context.fetch = input => {
            requests.push(['fetch', typeof input === 'string' ? input : input.url]);
            return embeddedFetch(input);
          };
          // The initial instantiateStreaming call happens synchronously above.
          for (const message of this.queue) this.context.onmessage({ data: message });
          this.queue = null;
        } catch (error) { this.fail(error); }
      }).catch(error => this.fail(error));
    }
    fail(error) { if (!this.closed) this.onerror?.({ message: String(error.message || error) }); }
    postMessage(message) {
      if (this.queue) this.queue.push(message);
      else queueMicrotask(() => {
        if (!this.closed) this.context.onmessage({ data: message });
      });
    }
    terminate() {
      this.closed = true;
      for (const timer of this.timers) clearTimeout(timer);
      this.timers.clear();
    }
  }
  const page = vm.createContext({
    Blob, atob, Worker: OfflineWorker,
    URL: {
      createObjectURL(blob) {
        const url = 'blob:null/offline-' + blobs.size;
        blobs.set(url, blob);
        return url;
      },
    },
    AndroidEngine: {
      onEngineReady: () => events.push(['ready']),
      onBestMove: (id, move) => events.push(['bestmove', id, move]),
      onEngineError: message => events.push(['error', message]),
    },
  });
  page.window = page;
  vm.runInContext(script, page, { timeout: 5000 });
  return {
    page, events, lines, requests,
    close() { for (const worker of workers) worker.terminate(); },
    async waitFor(predicate, label) {
      const deadline = Date.now() + 10000;
      while (!predicate()) {
        const error = events.find(event => event[0] === 'error');
        if (error) throw new Error(error[1]);
        if (Date.now() >= deadline) throw new Error('Timed out: ' + label +
          '; lines=' + JSON.stringify(lines.slice(-5)) + '; logs=' + JSON.stringify(logs.slice(-5)));
        await new Promise(resolve => setTimeout(resolve, 10));
      }
    },
  };
}

test('embedded Stockfish reaches uciok and readyok from an opaque Blob origin',
  { timeout: 15000 }, async () => {
    const h = harness();
    try {
      await h.waitFor(() => h.events.some(e => e[0] === 'ready'), 'engine ready');
      assert(h.lines.includes('uciok'));
      assert(h.lines.includes('readyok'));
      assert.equal(h.events.filter(e => e[0] === 'ready').length, 1);
      assert.equal(h.requests.filter(r => r[0] === 'xhr').length, 0);
    } finally { h.close(); }
  });

test('offline start position analysis returns a legal UCI move with the request ID',
  { timeout: 15000 }, async () => {
    const h = harness();
    try {
      await h.waitFor(() => h.events.some(e => e[0] === 'ready'), 'engine ready');
      h.page.analyzeFen('offline-start', startFen, 50);
      await h.waitFor(() => h.events.some(e => e[0] === 'bestmove'), 'bestmove');
      const result = h.events.find(e => e[0] === 'bestmove');
      assert.equal(result[1], 'offline-start');
      const legal = ['b1a3', 'b1c3', 'g1f3', 'g1h3'];
      for (const file of 'abcdefgh') legal.push(file + '2' + file + '3', file + '2' + file + '4');
      assert(legal.includes(result[2]), 'Illegal start-position move: ' + result[2]);
    } finally { h.close(); }
  });

test('cancelled search cannot report a stale result; latest request completes',
  { timeout: 15000 }, async () => {
    const h = harness();
    try {
      await h.waitFor(() => h.events.some(e => e[0] === 'ready'), 'engine ready');
      h.page.analyzeFen('old', startFen, 2000);
      await h.waitFor(() => vm.runInContext('active !== null', h.page), 'search active');
      h.page.analyzeFen('latest', startFen, 50);
      await h.waitFor(() => h.events.some(e => e[0] === 'bestmove'), 'latest bestmove');
      assert.deepEqual(h.events.filter(e => e[0] === 'bestmove').map(e => e[1]), ['latest']);
    } finally { h.close(); }
  });

test('stopping an active search suppresses its callback and allows another search',
  { timeout: 15000 }, async () => {
    const h = harness();
    try {
      await h.waitFor(() => h.events.some(e => e[0] === 'ready'), 'engine ready');
      h.page.analyzeFen('cancelled', startFen, 2000);
      await h.waitFor(() => vm.runInContext('active !== null', h.page), 'search active');
      h.page.stopEngineSearch();
      await h.waitFor(() => vm.runInContext('active === null', h.page), 'stopped');
      assert.equal(h.events.filter(e => e[0] === 'bestmove').length, 0);
      h.page.analyzeFen('after-stop', startFen, 50);
      await h.waitFor(() => h.events.some(e => e[0] === 'bestmove'), 'after-stop bestmove');
      assert.equal(h.events.find(e => e[0] === 'bestmove')[1], 'after-stop');
    } finally { h.close(); }
  });
