# گزارش آزمون آفلاین Stockfish

علت بازتولیدشدهٔ `ENGINE ERROR`: آدرس Worker از نوع Blob است و نام فایل
`.js` ندارد. loader تعبیه‌شده، در نبود بخش `#`، آدرس WASM را از
`location.origin + location.pathname` می‌سازد. برای مبدأ فایل، نمونهٔ این
آدرس `nullnull/offline-0` است. تابع fetch داخلی آن را رد می‌کند و خطا به
`onEngineError` می‌رسد. این مشکل به نبود اینترنت مربوط نیست.

اصلاح: افزودن `#stockfish.wasm` به آدرس Worker، مطابق قرارداد موجود loader.
تابع fetch داخلی اکنون WASM تعبیه‌شده را برمی‌گرداند؛ باینری موتور تغییر نکرده است.

## اجرا

پیش‌نیاز: Node.js نسخهٔ ۲۰ یا جدیدتر. وابستگی npm، Android SDK، سرور یا
دسترسی شبکه لازم نیست. در Linux:

```sh
timeout 60s node tests/offline/stockfish.test.cjs
```

هر تست سقف ۱۵ ثانیه و هر انتظار سقف ۱۰ ثانیه دارد. فرمان بالا کل اجرا را
نیز به ۶۰ ثانیه محدود می‌کند. آزمون‌ها HTML، loader و WASM واقعی پروژه را
در contextهای جداگانهٔ VM اجرا می‌کنند. تحویل پیام Worker به‌صورت ناهمگام
شبیه‌سازی می‌شود؛ fetch تنها از WASM تعبیه‌شده پاسخ می‌گیرد و XHR مسدود است.

## نتایج تأییدشده

- HTML اصلی ZIP: تست آماده‌شدن شکست خورد؛ پیام دقیق:
  `offline worker blocked fetch: nullnull/offline-0`، مدت کل حدود ۰٫۰۸ ثانیه.
- نسخهٔ اصلاح‌شده: ۴ تست موفق، ۰ شکست، مدت کل حدود ۰٫۸۸ ثانیه.
- پوشش: handshakeهای `uciok` و `readyok`؛ حرکت مجاز از وضعیت شروع همراه
  با شناسهٔ درخواست؛ حذف نتیجهٔ درخواست لغوشده و تکمیل آخرین درخواست؛
  توقف جست‌وجو و اجرای درخواست جدید.

برای آزمون فایل اصلی، HTML آن را از ZIP استخراج کنید و مسیرش را بدهید:

```sh
ENGINE_HOST_PATH=/path/to/original.html timeout 20s node --test-name-pattern='embedded Stockfish' tests/offline/stockfish.test.cjs
```

این اجرا آزمون Android/WebView نیست. تلاش برای اجرای Chromium به‌دلیل
محدودیت ساخت سوکت محیط (`Operation not permitted`) متوقف شد؛ اجرای واقعی
روی Android و ساخت APK تأیید نشده‌اند. طبق درخواست نهایی، آزمون وضعیت
شطرنج در این مرحله انجام نشد و هیچ کد همگام‌سازی یا overlay تغییر نکرد.

## فایل‌های تغییرکرده

- `app/src/main/assets/engine_host.html`: تنها تغییر کد برنامه، تعیین مسیر WASM.
- `tests/offline/stockfish.test.cjs`: فایل جدیدِ چهار تست خودکار آفلاین.
- `tests/offline/README.md`: فایل جدیدِ این گزارش و دستور اجرا.
